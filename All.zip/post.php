<?php include 'visitor_tracker.php'; ?><?php
include('db.php');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $conn->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $title = htmlspecialchars($row['title']);
    $content = $row['content'];
} else {
    $title = "Post Not Found";
    $content = "<p>The blog post you are looking for does not exist.</p>";
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title><?php echo $title; ?> | TOOLOI</title>
  <link rel="stylesheet" href="styles.css" />
  <link rel="stylesheet" href="styless.css" />
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <nav class="sidebar" id="sidebar">
    <h2.0>.</h2.0>     
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="blog.php">Blog</a>
    <a href="terms-conditions.php">Terms and Conditions</a>
    <a href="privacy-policy.php">Privacy Policy</a>
  </nav>

  <div class="main">
    <header>
      <h1><?php echo $title; ?></h1>
    </header>

    <div class="ad-slot">[ Ad Space - Insert Your Ad Code Here ]</div>

    <div class="post-card" style="margin: 20px;">
      <?php echo $content; ?>
    </div>

    <footer>
      &copy; 2025 TOOLOI. All rights reserved.
    </footer>
  </div>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }
  </script>

</body>
</html>