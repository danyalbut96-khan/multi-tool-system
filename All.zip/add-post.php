<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add New Post</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Same CSS as you provided -->
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      color: #222;
    }

    .menu-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    .main {
      padding: 70px 20px 20px;
      max-width: 800px;
      margin: auto;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    header h1 {
      font-size: 2.2em;
    }

    form {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      margin-top: 30px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      font-weight: bold;
    }

    input[type="text"],
    textarea,
    input[type="file"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 16px;
    }

    input[type="submit"] {
      background: #007bff;
      color: white;
      padding: 12px 25px;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background: #0056b3;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="document.querySelector('.sidebar').classList.toggle('open')">☰ Menu </button>

  <div class="sidebar">
    <h2>...</h2>
    <a href="admin-dashboard.php">Dashboard</a>
    <a href="add-post.php">Add Post</a>
    <a href="manage-posts.php">Manage Posts</a>
    <a href="settings.php">Settings</a>
    <a href="logout.php">Logout</a>
  </div>

  <div class="main">
    <header>
      <h1>Add New Blog Post</h1>
    </header>

    <form action="process_add_post.php" method="POST" enctype="multipart/form-data">
      <label>Title:</label>
      <input type="text" name="title" required>

      <label>Content:</label>
      <textarea name="content" rows="10" required></textarea>

      <label>Upload Image (optional):</label>
      <input type="file" name="image">

      <input type="submit" name="submit" value="Add Post">
    </form>
  </div>

  <footer>
    &copy; 2025 TOOLoi Blog Admin | All rights reserved.
  </footer>

</body>
</html>