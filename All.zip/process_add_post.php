<?php
session_start();
require_once 'db.php'; // existing DB connection

// چیک کریں کہ یوزر لاگ ان ہے یا نہیں
if (!isset($_SESSION["admin_id"])) {
    header("Location: admin-login.php");
    exit();
}

// اگر فارم سبمٹ ہوا ہے
if (isset($_POST['submit'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);

    // image upload
    $image_name = null;
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_ext = pathinfo($image, PATHINFO_EXTENSION);
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array(strtolower($image_ext), $allowed)) {
            $image_name = time() . '_' . rand(100, 999) . '.' . $image_ext;
            move_uploaded_file($image_tmp, "uploads/" . $image_name);
        }
    }

    // ڈیٹا بیس میں انسرت کریں
    $sql = "INSERT INTO posts (title, content, image, created_at) 
            VALUES ('$title', '$content', '$image_name', NOW())";

    if (mysqli_query($conn, $sql)) {
        $_SESSION['message'] = "Post added successfully!";
    } else {
        $_SESSION['message'] = "Error: " . mysqli_error($conn);
    }

    header("Location: admin-dashboard.php"); // Redirect after insertion
    exit();
} else {
    header("Location: add-post.php"); // اگر غلطی سے کوئی ڈائریکٹ آئے
    exit();
}
?>