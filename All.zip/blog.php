<?php include('db.php'); ?>
<?php include 'visitor_tracker.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>TOOLOI - Blog</title>
  <link rel="stylesheet" href="styles.css" />
  <link rel="stylesheet" href="styless.css" />
  <link rel="icon" href="favicon.ico" type="image/x-icon">
  <style>
    .search-bar {
      margin: 20px;
      text-align: center;
    }
    .search-bar input {
      padding: 10px;
      width: 60%;
      font-size: 16px;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    .post-card {
      background: #fff;
      margin: 20px;
      padding: 20px;
      border-radius: 16px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .read-more-btn {
      display: inline-block;
      margin-top: 10px;
      padding: 8px 16px;
      background: #007bff;
      color: #fff;
      text-decoration: none;
      border-radius: 8px;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <nav class="sidebar" id="sidebar">
         <h2.0>....</h2.0>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="blog.php">Blog</a>
    <a href="terms-conditions.php">Terms and Conditions</a>
    <a href="privacy-policy.php">Privacy Policy</a>
  </nav>

  <div class="main">
    <header>
      <h1>Our Blog</h1>
      <p>Latest posts and updates from TOOLOI</p>
    </header>

    <div class="ad-slot">[ Ad Space - Insert Your Ad Code Here ]</div>

    <div class="search-bar">
      <input type="text" id="searchInput" placeholder="Search blog posts..." oninput="loadPosts(true)">
    </div>

    <div id="blog-posts"></div>

    <div id="loading" style="text-align:center; padding: 20px;">Loading more posts...</div>

    <footer>
      &copy; 2025 TOOLOI. All rights reserved.
    </footer>
  </div>

  <script>
    let offset = 0;
    let loading = false;
    let searchQuery = '';

    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    function loadPosts(reset = false) {
      if (loading) return;
      loading = true;

      if (reset) {
        offset = 0;
        document.getElementById("blog-posts").innerHTML = '';
        searchQuery = document.getElementById("searchInput").value.trim();
      }

      fetch(`load_posts.php?offset=${offset}&search=${encodeURIComponent(searchQuery)}`)
        .then(res => res.text())
        .then(data => {
          if (data.trim() === '') {
            document.getElementById("loading").innerText = "No more posts.";
          } else {
            document.getElementById("blog-posts").insertAdjacentHTML('beforeend', data);
            offset += 5;
            loading = false;
          }
        });
    }

    // Load initial posts
    window.onload = loadPosts;

    // Infinite scroll
    window.onscroll = function () {
      if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 100) {
        loadPosts();
      }
    };
  </script>

</body>
</html>