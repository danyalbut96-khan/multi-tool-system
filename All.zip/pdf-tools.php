<?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>TOOLOI - PDF Tools</title>
  <meta name="description" content="TOOLOI - PDF tools like PDF to Word, Word to PDF, PDF compression, merging, and splitting.">
  <link rel="stylesheet" href="styles.css" />
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <nav class="sidebar" id="sidebar">
    <h2></h2>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
  </nav>

  <div class="main">
    <header>
      <h1>PDF Tools</h1>
      <p>Manage and convert your PDF files quickly and easily</p>
    </header>

    <div class="ad-slot">  <?php include 'ads.php'; ?> </div>

    <div class="tools-grid">
      
      <div class="tool-card"><h3>PDF Compressor</h3><a href="tools/pdf-compressor.php" target="_blank">Launch</a></div>
      <div class="tool-card"><h3>Merge PDFs</h3><a href="tools/merge-pdfs.php" target="_blank">Launch</a></div>
      <div class="tool-card"><h3>Split PDF</h3><a href="tools/split-pdf.php" target="_blank">Launch</a></div>
    </div>
 <div class="ad-slot"> <?php include 'ads.php'; ?> </div>
 <section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● PDF Tools – Simplify Your Digital Paperwork ●☆</h2>
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Tired of juggling multiple PDF tasks? TOOLOI's <a href="pdf-tools.php"><strong>PDF Tools</strong></a> are your go-to solution for handling documents quickly and efficiently—no downloads, no stress. Just upload your files and let our smart tools do the rest!
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ PDF Merger:</strong> Merge multiple PDF files into a single, organized document in seconds. Perfect for contracts, reports, eBooks, or study materials. Our <strong>free online PDF merger</strong> keeps your formatting intact and your workflow smooth.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ PDF Splitter:</strong> Need just one page or a section from a big PDF? Our <strong>PDF splitter tool</strong> lets you extract pages easily. Whether you’re creating handouts or splitting chapters, you’re in full control—fast, accurate, and secure.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ PDF Compressor:</strong> Reduce PDF file size without compromising quality. Ideal for emailing documents, uploading resumes, or saving storage. Our <strong>online PDF compressor</strong> ensures fast uploads and lightning-fast downloads.
    </p>

    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Whether you're a student, professional, or casual user, TOOLOI’s <strong>free online PDF tools</strong> save time, reduce file bloat, and make document management a breeze. Try them now and take control of your PDFs like never before!
    </p>
  </div> <?php include 'ads.php'; ?> 
</section>

<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆● Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Format, minify, and test your code like a pro😍🤩.</p>
        </div>
      </a>
    </div>
  </div>
</section>
 <?php include 'ads.php'; ?> 
    <footer>
      &copy; 2025 TOOLOI. All rights reserved.
    </footer>
  </div>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }
  </script>

</body>
</html>