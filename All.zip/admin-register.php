<!DOCTYPE html><html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Register</title>
  <link rel="stylesheet" href="/assets/css/sidebar.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
    }
    .main {
      padding: 80px 20px;
      max-width: 400px;
      margin: auto;
    }
    .form-box {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .form-box h2 {
      margin-bottom: 20px;
      text-align: center;
    }
    .form-box input[type="text"],
    .form-box input[type="password"] {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    .form-box button {
      width: 100%;
      padding: 12px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      margin-top: 10px;
    }
    .form-box button:hover {
      background: #0056b3;
    }
    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 60px;
      background: #f0f0f0;
    }
  </style>
</head>
<body>
  <button class="menu-btn" onclick="document.querySelector('.sidebar').classList.toggle('open')">Menu</button>  <div class="sidebar">
    <h2>TOOLOI</h2>
    <a href="/index.html">Home</a>
    <a href="/about.html">About</a>
  </div>  <div class="main">
    <div class="form-box">
      <h2>Admin Register</h2>
      <form method="POST" action="process-register.php">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Register</button>
      </form>
    </div>
  </div>  <footer>
    &copy; 2025 TOOLOI. All rights reserved.
  </footer>
</body>
</html>