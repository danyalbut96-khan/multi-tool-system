<?php
$host = "localhost";
$db = "u797517455_Tooloi";
$user = "u797517455_Tooloi";
$pass = "Tooloi96@12";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>