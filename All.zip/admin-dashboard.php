<?php 
include('db.php');

session_start();

// 7 دن = 7 دن * 24 گھنٹے * 60 منٹ * 60 سیکنڈ
$session_lifetime = 7 * 24 * 60 * 60;

// اگر یوزر لاگ ان ہے
if (isset($_SESSION['admin_id'])) {

    // پہلی بار لاگ ان پر ٹائم اسٹور کریں
    if (!isset($_SESSION['last_login_time'])) {
        $_SESSION['last_login_time'] = time();
    }

    // اگر ٹائم ایکسپائر ہو چکا ہے
    if (time() - $_SESSION['last_login_time'] > $session_lifetime) {
        // سیشن ختم کریں اور لاگ آؤٹ کریں
        session_unset();
        session_destroy();
        header("Location: admin-login.php?session=expired");
        exit();
    }

    // اگر ایکسپائر نہیں ہوا، تو ہر پیج لوڈ پر ٹائم اپڈیٹ نہ کریں تاکہ 7 دن فکس رہیں
    // اگر آپ چاہتے ہیں کہ ایکٹیو یوزر کے لیے ٹائم ریفریش ہو تو اس لائن کو ان کامنٹ کریں:
    // $_SESSION['last_login_time'] = time();

} else {
    header("Location: admin-login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard - Tooloi</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://tooloi.earningera.com/sidebar.css"> <!-- External CSS if you're using one -->
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      color: #222;
    }

    .menu-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 8px 12px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0;
      left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    .main {
      padding: 70px 20px 20px 240px;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    header h1 {
      font-size: 2em;
    }

    .dashboard-links {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-top: 30px;
    }

    .dash-card {
      background: white;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      text-align: center;
      transition: 0.3s;
    }

    .dash-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.15);
    }

    .dash-card a {
      display: inline-block;
      margin-top: 10px;
      background: #007bff;
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 6px;
    }

    .dash-card a:hover {
      background: #0056b3;
    }
    
    .footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }
  </style>
</head>
<body>

<button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

<div class="sidebar" id="sidebar">
  <h2>..</h2>
   <a href="index.php">Home</a>
  <a href="admin-dashboard.php">Dashboard</a>
  <a href="add-post.php">Add Post</a>
  <a href="manage-posts.php">Manage Posts</a>
  <a href="settings.php">Blog Settings</a>
  <a href="analytics.php">Analytics</a>
  <a href="logout.php">Logout</a>
</div>

<header>
  <h1>Welcome, <?php echo $_SESSION["username"]; ?>!</h1>
  <p>Manage your blog posts, settings, and analytics here.</p>
</header>

<div class="main">
  <div class="dashboard-links">
    <div class="dash-card">
      <h3>Add New Blog Post</h3>
      <a href="add-post.php">Go to Add Post</a>
    </div>
    <div class="dash-card">
      <h3>Manage Blog Posts</h3>
      <a href="manage-posts.php">Manage  Posts</a>
    </div>
    <div class="dash-card">
      <h3>Update Blog Settings</h3>
      <a href="settings.php">Open Settings</a>
    </div>
    <div class="dash-card">
      <h3>View Analytics</h3>
      <a href="analytics.php">Open Analytics</a>
    </div>
    
     <div class="ad-slot">[ Ad Space - Insert Your Ad Code Here ]</div>


<footer>
  &copy; 2025 Tooloi. All rights reserved.
</footer>

<script>
    let offset = 0;
    let loading = false;
    let searchQuery = '';

    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    function loadPosts(reset = false) {
      if (loading) return;
      loading = true;

      if (reset) {
        offset = 0;
        document.getElementById("blog-posts").innerHTML = '';
        searchQuery = document.getElementById("searchInput").value.trim();
      }

      fetch(`load_posts.php?offset=${offset}&search=${encodeURIComponent(searchQuery)}`)
        .then(res => res.text())
        .then(data => {
          if (data.trim() === '') {
            document.getElementById("loading").innerText = "No more posts.";
          } else {
            document.getElementById("blog-posts").insertAdjacentHTML('beforeend', data);
            offset += 5;
            loading = false;
          }
        });
    }

    // Load initial posts
    window.onload = loadPosts;

    // Infinite scroll
    window.onscroll = function () {
      if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 100) {
        loadPosts();
      }
    };
  </script>

</body>
</html>