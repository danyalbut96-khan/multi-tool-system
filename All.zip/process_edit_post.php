<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: admin-login.php");
  exit();
}

require_once 'db.php';

if (isset($_POST['submit'])) {
  $id = $_POST['id'];
  $title = mysqli_real_escape_string($conn, $_POST['title']);
  $content = mysqli_real_escape_string($conn, $_POST['content']);

  if (!empty($_FILES['image']['name'])) {
    $image = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $target = "uploads/" . basename($image);
    move_uploaded_file($image_tmp, $target);

    $query = "UPDATE posts SET title='$title', content='$content', image='$image' WHERE id=$id";
  } else {
    $query = "UPDATE posts SET title='$title', content='$content' WHERE id=$id";
  }

  if (mysqli_query($conn, $query)) {
    echo "<script>alert('Post updated successfully!'); window.location.href='manage-posts.php';</script>";
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>