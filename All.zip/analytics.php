<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Analytics | Tooloi Admin</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.css"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/chart.js/dist/Chart.min.css"/>
  <link rel="stylesheet" href="https://tooloi.earningera.com/sidebar.css"/>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      transition: margin-left 0.3s ease;
    }
    .open .sidebar { left: 0; }
    .open main { margin-left: 220px; }
    main {
      padding: 20px;
      margin-left: 0;
      transition: margin-left 0.3s ease;
    }
    h1 { font-size: 24px; margin-bottom: 20px; margin-left: 220px; }
    .filters { margin-bottom: 20px; }
    .filters button {
      background: #007bff; color: white; border: none;
      padding: 6px 12px; margin-right: 8px;
      border-radius: 5px; cursor: pointer;
      margin-left: 20px;
    }
    .filters button:hover { background: #0056b3; }
    .chart-box {
      background: white; padding: 20px;
      border-radius: 12px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      margin-bottom: 30px;
    }
    #map {
      height: 400px; width: 100%;
      border-radius: 12px; margin-top: 20px;
    }
    table {
      width: 100%; margin-top: 15px;
      border-collapse: collapse;
    }
    table th, table td {
      padding: 10px; border: 1px solid #ccc; text-align: left;
    }
    .sidebar {
      position: fixed; top: 0; left: -220px;
      width: 220px; height: 100%;
      background: #007bff; color: white;
      transition: left 0.3s ease; padding-top: 60px; z-index: 1000;
    }
    .sidebar .logo {
      text-align: center; font-size: 20px;
      font-weight: bold; padding-bottom: 20px;
    }
    .sidebar nav {
      display: flex; flex-direction: column;
      gap: px; padding: 0 20px;
    }
    .sidebar nav a {
      color: white; text-decoration: none;
      padding: 10px; border-radius: 6px;
    }
    .sidebar nav a:hover,
    .sidebar nav a.active {
      background: rgba(255, 255, 255, 0.2);
    }
    .menu-toggle {
      position: fixed; top: 10px; left: 10px;
      font-size: 24px; background: #007bff; color: white;
      border: none; padding: 6px 10px;
      border-radius: 6px; cursor: pointer; z-index: 1100;
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<button class="menu-toggle" onclick="toggleSidebar()">≡ Menu</button>
<div class="sidebar" id="sidebar">
  <nav>
   
  <a href="admin-dashboard.php">Dashboard</a>
  <a href="add-post.php">Add Post</a>
  <a href="manage-posts.php">Manage Posts</a>
  <a href="settings.php">Blog Settings</a>
  <a href="analytics.php">Analytics</a>
  <a href="logout.php">Logout</a>
  </nav>
</div>

<main>
  <h1>Website Analytics Dashboard</h1>

  <div class="filters">
    <button onclick="loadData('live')">Live</button>
    <button onclick="loadData('24h')">24 Hours</button>
    <button onclick="loadData('7d')">7 Days</button>
    <button onclick="loadData('30d')">30 Days</button>
    <button onclick="loadData('1y')">1 Year</button>
    <button onclick="loadData('lifetime')">Lifetime</button>
  </div>

  <div class="chart-box">
    <h2>Views Over Time</h2>
    <canvas id="viewsChart"></canvas>
  </div>

  <div class="chart-box">
    <h2>Top Referrers</h2>
    <canvas id="referrersChart"></canvas>
  </div>

  <div class="chart-box">
    <h2>Top Countries</h2>
    <div id="map"></div>
    <table id="countryTable"></table>
  </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.js"></script>
<script>
  let viewsChart, referrersChart, map, markers = [];

  function toggleSidebar() {
    document.body.classList.toggle('open');
  }

  function loadData(filter = '7d') {
    fetch('get_analytics_data.php?filter=' + filter)
      .then(res => res.json())
      .then(data => {
        updateCharts(data);
        updateMap(data.top_countries);
      });
  }

  function updateCharts(data) {
    if (viewsChart) viewsChart.destroy();
    viewsChart = new Chart(document.getElementById('viewsChart'), {
      type: 'line',
      data: {
        labels: data.views.labels.reverse(), // REVERSE: Latest date on right
        datasets: [{
          label: 'Views',
          data: data.views.data.reverse(),
          borderColor: '#007bff',
          backgroundColor: 'rgba(0,123,255,0.1)',
          tension: 0.4,
          pointRadius: 3,
          pointBackgroundColor: '#007bff',
          fill: true
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#fff',
            titleColor: '#000',
            bodyColor: '#000',
            borderColor: '#ccc',
            borderWidth: 1
          }
        },
        scales: {
          x: {
            title: { display: true, text: 'Date' },
            ticks: { color: '#333' }
          },
          y: {
            beginAtZero: true,
            title: { display: true, text: 'Views' },
            ticks: { color: '#333' }
          }
        }
      }
    });

    if (referrersChart) referrersChart.destroy();
    referrersChart = new Chart(document.getElementById('referrersChart'), {
      type: 'pie',
      data: {
        labels: data.referrers.labels,
        datasets: [{
          data: data.referrers.data,
          backgroundColor: ['#007bff', '#28a745', '#ffc107', '#dc3545', '#6f42c1']
        }]
      }
    });
  }

  function updateMap(countries) {
    if (!map) {
      map = L.map('map').setView([20, 0], 2);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
    }
    markers.forEach(m => map.removeLayer(m));
    markers = [];

    let tableHtml = '<tr><th>Country</th><th>Visits</th></tr>';
    countries.forEach(c => {
      tableHtml += `<tr><td>${c.country}</td><td>${c.count}</td></tr>`;
      if (c.lat && c.lon) {
        markers.push(L.marker([c.lat, c.lon]).addTo(map).bindPopup(`${c.country}: ${c.count}`));
      }
    });
    document.getElementById('countryTable').innerHTML = tableHtml;
  }

  loadData(); // Default load
</script>
</body>
</html>