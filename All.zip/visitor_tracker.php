<?php
include 'db.php';

function getUserIP() {
    return $_SERVER['REMOTE_ADDR'];
}

function getUserAgentData() {
    $agent = $_SERVER['HTTP_USER_AGENT'];
    $platform = 'Unknown';
    $browser = 'Unknown';
    $device = 'Desktop';

    // Platform detection
    if (preg_match('/linux/i', $agent)) $platform = 'Linux';
    elseif (preg_match('/macintosh|mac os x/i', $agent)) $platform = 'Mac';
    elseif (preg_match('/windows|win32/i', $agent)) $platform = 'Windows';
    elseif (preg_match('/android/i', $agent)) $platform = 'Android';
    elseif (preg_match('/iphone/i', $agent)) $platform = 'iPhone';

    // Browser detection
    if(preg_match('/MSIE/i',$agent)) $browser = 'Internet Explorer';
    elseif(preg_match('/Firefox/i',$agent)) $browser = 'Firefox';
    elseif(preg_match('/Chrome/i',$agent)) $browser = 'Chrome';
    elseif(preg_match('/Safari/i',$agent)) $browser = 'Safari';
    elseif(preg_match('/Opera/i',$agent)) $browser = 'Opera';

    // Device type
    if (preg_match('/mobile/i', $agent)) $device = 'Mobile';
    elseif (preg_match('/tablet/i', $agent)) $device = 'Tablet';

    return [$platform, $browser, $device];
}

$ip = getUserIP();

// Get country using ip-api
$country = 'Unknown';
$geoData = @json_decode(file_get_contents("http://ip-api.com/json/$ip"), true);
if ($geoData && $geoData['status'] == 'success') {
    $country = $geoData['country'];
}

$page = $_SERVER['REQUEST_URI'];
[$platform, $browser, $device] = getUserAgentData();

$stmt = $conn->prepare("INSERT INTO visitors (ip_address, country, browser, platform, device, page) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $ip, $country, $browser, $platform, $device, $page);
$stmt->execute();
?>