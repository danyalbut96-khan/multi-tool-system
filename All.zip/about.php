<?php include 'visitor_tracker.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="title" content="About TOOLOI - Online Free Tools Hub">
  <meta name="description" content="Learn more about TOOLOI – a free, fast, and mobile-friendly platform offering text tools, image editors, PDF utilities, and more to simplify your daily tasks.">
  <meta name="keywords" content="TOOLOI, online tools, text tools, image tools, PDF converter, unit converter, free tools website, paraphrasing tool, image resizer, meme generator, OCR tool">
  <meta name="author" content="TOOLOI Team">
  <title>About - TOOLOI</title>

  <!-- Inline CSS based on your provided style -->
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      color: #222;
    }

    .menu-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    .main {
      padding: 70px 20px 20px;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    header h1 {
      font-size: 2.2em;
    }

    .ad-slot {
      margin: 40px 0;
      background: #eaeaea;
      padding: 30px;
      text-align: center;
      border: 2px dashed #ccc;
      color: #666;
      font-style: italic;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <h2></h2>
    <a href="index.php">Home</a>
    <a href="blog.php">Blog</a>
    
  </div>

  <!-- Mobile Menu Button -->
  <button class="menu-btn" onclick="toggleSidebar()">Menu</button>

  <!-- Header -->
  <header>
    <h1>About TOOLOI</h1>
  </header>

  <!-- Main Content -->
  <div class="main">
    <p><strong>Welcome to TOOLOI – Your One-Stop Online Tool Hub!</strong></p>
    <p>TOOLOI is a free, user-friendly web platform offering powerful tools for everyday tasks. From content creation to image editing and essential utilities, we make productivity easier and faster—right from your browser.</p>
 <?php include 'ads.php'; ?> 
    <h2 style="margin-top:20px;">What We Offer</h2>
    <ul style="margin-top:10px; padding-left: 20px;">
      <li>Text & Content Tools: Paraphrasing, summarizing, grammar checking, and more.</li>
      <li>Image Tools: Resize, compress, convert, background removal, meme creation, OCR.</li>
      <li>PDF Tools: Convert, merge, compress, or split PDFs with ease.</li>
      <li>Unit & Conversion Tools: Convert currency, units, time zones, BMI, and more.</li>
      <li>Developer Tools: HTML/CSS/JS minify and run utilities for coders.</li>
    </ul>

    <h2 style="margin-top:20px;">Why Choose TOOLOI?</h2>
    <ul style="margin-top:10px; padding-left: 20px;">
      <li>Fast, secure, and ad-light experience</li>
      <li>Mobile-optimized & easy to use</li>
      <li>No sign-up required</li>
      <li>Completely free for everyone</li>
    </ul>
 <?php include 'ads.php'; ?> 
    <h2 style="margin-top:20px;">Our Mission</h2>
    <p style="margin-top:10px;">TOOLOI aims to simplify digital life by providing accessible, efficient tools for everyone—from casual users to professionals and developers.</p>

    <h2 style="margin-top:20px;">Connect With Us</h2>
    <p style="margin-top:10px;">Got feedback or suggestions? We’re always improving and adding new tools to meet your needs.</p>

    <!-- Ads Section -->
    <div class="ad-slot"> <?php include 'ads.php'; ?> </div>
  </div>
 <?php include 'ads.php'; ?> 
  <!-- Footer -->
  <footer>
    <p>&copy; 2025 TOOLOI. All rights reserved.</p>
  </footer>

  <!-- JavaScript -->
  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }
  </script>
</body>
</html>