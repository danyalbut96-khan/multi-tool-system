<?php include 'visitor_tracker.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="title" content="Terms and Conditions - TOOLOI">
  <meta name="description" content="Read the detailed terms and conditions for using TOOLOI's free online tools.">
  <meta name="keywords" content="terms, conditions, TOOLOI, user agreement, online tools terms">
  <meta name="author" content="TOOLOI Team">
  <title>Terms & Conditions - TOOLOI</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', sans-serif; background: #f5f7fa; color: #222; }
    .menu-btn {
      position: fixed; top: 15px; left: 15px; z-index: 1001;
      background: #007bff; color: white; padding: 10px 15px;
      border: none; border-radius: 5px; cursor: pointer;
    }
    .sidebar {
      position: fixed; top: 0; left: 0; width: 220px; height: 100%;
      background: #007bff; color: white; padding: 20px;margin-top:50px; 
      transform: translateX(-100%); transition: transform 0.3s ease;
      z-index: 1000;
    }
    .sidebar.open { transform: translateX(0); }
    .sidebar a {
      display: block; color: white; text-decoration: none;
      margin: 15px 0; font-size: 1.1em;
    }
    .main { padding: 70px 20px 20px; }
    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white; padding: 30px 20px; text-align: center;
    }
    header h1 { font-size: 2.2em; }
    h2 { margin-top: 30px; font-size: 1.5em; }
    p, li { margin-top: 10px; line-height: 1.6; }
    footer {
      text-align: center; padding: 30px 0;
      margin-top: 40px; background: #f0f0f0;
    }
  </style>
</head>
<body>
  <div class="sidebar" id="sidebar">
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="blog.php">Blog</a>
    <a href="privacy-policy.php">Privacy Policy</a>
  </div>

  <button class="menu-btn" onclick="toggleSidebar()">Menu</button>

  <header>
    <h1>Terms & Conditions</h1>
  </header>

  <div class="main">
    <p>Welcome to <strong>TOOLOI</strong>. By accessing or using our website, you agree to comply with and be bound by the following terms and conditions.</p>

    <h2>1. Acceptance of Terms</h2>
    <p>Using TOOLOI means you accept all our terms. If you disagree, please discontinue use.</p>

    <h2>2. User Responsibilities</h2>
    <ul>
      <li>You agree to use the tools ethically and legally.</li>
      <li>No spam, harmful scripts, or abuse is tolerated.</li>
      <li>You are responsible for any actions taken using the results from our tools.</li>
    </ul>

    <h2>3. Accuracy of Tools</h2>
    <p>We strive for accuracy but cannot guarantee 100% correctness of every tool. Use your discretion before relying fully on results.</p>

    <h2>4. Changes to Service</h2>
    <p>We may modify, suspend, or remove tools anytime without notice. We're constantly improving!</p>

    <h2>5. Limitation of Liability</h2>
    <p>TOOLOI shall not be held responsible for any damages resulting from the use or inability to use the tools provided.</p>

    <h2>6. Governing Law</h2>
    <p>These terms are governed by the laws of your local jurisdiction, and disputes will be resolved accordingly.</p>
  </div>

  <footer>
    <p>&copy; 2025 TOOLOI. All rights reserved.</p>
  </footer>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }
  </script>
</body>
</html>