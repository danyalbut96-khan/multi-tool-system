<?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>TOOLOI - Developer Tools</title>
  <meta name="description" content="TOOLOI - Developer tools like HTML/CSS/JS Minifier and Code Runner.">
  <link rel="stylesheet" href="styles.css" />
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <nav class="sidebar" id="sidebar">
    <h2></h2>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
  </nav>

  <div class="main">
    <header>
      <h1>Developer Tools</h1>
      <p>Handy tools for web developers to test and optimize code</p>
    </header>

    <div class="ad-slot"> <?php include 'ads.php'; ?> </div>

    <div class="tools-grid">
      <div class="tool-card"><h3>HTML/CSS/JS Minifier</h3><a href="tools/minifier.php" target="_blank">Launch</a></div>
      <div class="tool-card"><h3>HTML/CSS/JS Runner</h3><a href="tools/code-runner.php" target="_blank">Launch</a></div>
    </div> <?php include 'ads.php'; ?> 
    <section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Developer Tools – Enhance Your Coding Workflow ●☆</h2>
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Need powerful tools to streamline your web development process? TOOLOI’s <a href="developer-tools.php"><strong>Developer Tools</strong></a> provide you with the best solutions for efficient code editing and optimization. Whether you're a beginner or an experienced developer, our tools simplify your coding tasks with precision and speed.
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ HTML Code Runner:</strong> Write, test, and execute HTML code instantly with the <strong>HTML Code Runner</strong>. This tool allows you to quickly preview your HTML projects without leaving your browser, helping you work faster and more efficiently.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Code Minifier (HTML, CSS, JS):</strong> Need to reduce your code size for better performance? Our <strong>Code Minifier</strong> helps you compress HTML, CSS, and JavaScript files by removing unnecessary spaces, comments, and characters. It makes your code more efficient and improves page loading speeds, perfect for optimizing your websites and apps.
    </p>

    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Whether you're running HTML code live or minifying your files for faster loading, TOOLOI's <strong>Developer Tools</strong> make web development tasks quicker, easier, and more optimized. Enhance your coding experience with our free online tools!
    </p>
  </div>
</section> <?php include 'ads.php'; ?> 
<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆● Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Format, minify, and test your code like a pro😍🤩.</p>
        </div>
      </a>
    </div>
  </div>
</section>
 <?php include 'ads.php'; ?> 
    <footer>
      &copy; 2025 TOOLOI. All rights reserved.
    </footer>
  </div>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }
  </script>

</body>
</html>