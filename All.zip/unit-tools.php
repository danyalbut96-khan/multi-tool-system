<?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>TOOLOI - Unit & Conversion Tools</title>
  <meta name="description" content="TOOLOI - Tools for unit and conversion: currency, time zones, age, BMI, and general unit converters.">
  <link rel="stylesheet" href="styles.css" />
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <nav class="sidebar" id="sidebar">
    <h2></h2>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
  </nav>

  <div class="main">
    <header>
      <h1>Unit & Conversion Tools</h1>
      <p>Convert and calculate with our accurate and easy tools</p>
    </header>

    <div class="ad-slot">  <?php include 'ads.php'; ?> </div>

    <div class="tools-grid">
      <div class="tool-card"><h3>Currency Converter</h3><a href="tools/currency-converter.php" target="_blank">Launch</a></div>
      <div class="tool-card"><h3>Time Zone Converter</h3><a href="tools/time-zone-converter.php" target="_blank">Launch</a></div>
      <div class="tool-card"><h3>Age Calculator</h3><a href="tools/age-calculator.php" target="_blank">Launch</a></div>
      <div class="tool-card"><h3>BMI Calculator</h3><a href="tools/bmi-calculator.php" target="_blank">Launch</a></div>
      <div class="tool-card"><h3>Unit Converter</h3><a href="tools/unit-converter.php" target="_blank">Launch</a></div>
    </div>
     <?php include 'ads.php'; ?> 
<section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Unit & Conversion Tools – Convert with Ease ●☆</h2>
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Need to convert measurements, currencies, or time zones quickly? TOOLOI’s <a href="unit-tools.php"><strong>Unit & Conversion Tools</strong></a> simplify all your conversions in a matter of seconds—no complexity, just fast results!
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Unit Converter:</strong> Convert length, weight, volume, temperature, and more with ease. Whether you're a student or a professional, this tool is a must-have for accurate and fast conversions.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Currency Converter:</strong> Need to convert currencies for your next international trip? Our <strong>Currency Converter</strong> provides real-time exchange rates and simplifies foreign transactions.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Time Zone Converter:</strong> Struggling to schedule a meeting across time zones? The <strong>Time Zone Converter</strong> tool helps you plan meetings, calls, or appointments without confusion, even across different countries!
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Age Calculator:</strong> Find out how old you are in years, months, and days, with the <strong>Age Calculator</strong> tool. It's a simple and fun tool for anyone who needs to calculate age for any purpose.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ BMI Calculator:</strong> Want to know if you’re within a healthy weight range? Our <strong>BMI Calculator</strong> helps track your body mass index based on your height and weight, supporting your health goals.
    </p>

    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Whether you're calculating your BMI, converting units or currencies, or figuring out time zones, TOOLOI's <strong>free online conversion tools</strong> make everything easier, faster, and more accurate!
    </p>
  </div>
</section>
 <?php include 'ads.php'; ?> 
<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆● Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Format, minify, and test your code like a pro😍🤩.</p>
        </div>
      </a>
    </div>
  </div>
</section> <?php include 'ads.php'; ?> 
    <footer>
      &copy; 2025 TOOLOI. All rights reserved.
    </footer>
  </div>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }
  </script>

</body>
</html>