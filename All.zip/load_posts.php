<?php include('db.php');

$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$limit = 5;

$sql = "SELECT * FROM posts";
$params = [];

if ($search !== '') {
    $sql .= " WHERE title LIKE ? OR content LIKE ?";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " ORDER BY created_at DESC LIMIT $limit OFFSET $offset";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param(str_repeat("s", count($params)), ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    echo '<div class="post-card">';
    echo '<h2>' . htmlspecialchars($row['title']) . '</h2>';
    echo '<p>' . substr(strip_tags($row['content']), 0, 200) . '...</p>';
    echo '<a href="post.php?id=' . $row['id'] . '" class="read-more-btn">Read More</a>';
    echo '</div>';
}

$stmt->close();
?>