<?php include('db.php'); ?>
<?php include 'visitor_tracker.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <meta name="google-site-verification" content="-XSmUIQ3Sz-rTny-pRQj5BS_HOqLksTEeLO8N7xKvTY" />
  <meta name="description" content="TOOLOI is your all-in-one online tool hub featuring image editors, text content generators, file converters, developer utilities, and advanced analytics — all for free, fast, and mobile-friendly. Perfect for creators, students, and developers.">
  <title>TOOLOI - Home | All in one free online tools</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Segoe+UI&display=swap"/>
  <link rel="icon" href="favicon.ico" type="image/x-icon">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f4f6f9;
      color: #222;
    }

    .menu-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 6px 10px;
      font-size: 14px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0;
      left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
    }
     .sidebar h2.0 {
     font-size: 1.5em;
     margin-bottom: 7000px;
    }

    .main {
      padding: 70px 20px 20px;
      max-width: 1200px;
      margin: auto;
    }

    header {
      text-align: center;
      background: linear-gradient(135deg, #007bff, #00c6ff);
      color: white;
      padding: 40px 20px;
      border-radius: 12px;
    }

    header h1 {
      font-size: 2.5em;
      margin-bottom: 10px;
    }

    .ad-slot {
      background: #eaeaea;
      text-align: center;
      padding: 20px;
      margin: 30px auto;
      border-radius: 10px;
      font-style: italic;
    }

    .tool-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
      margin: 40px 0;
    }

    .category-card {
      background: white;
      padding: 20px;
      border-radius: 10px;
      text-align: center;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
    }

    .category-card h2 {
      font-size: 1.2em;
      margin-bottom: 50px;
    }

    .click-btn {
      background: #007bff;
      color: white;
      padding: 10px 20px;
      border-radius: 6px;
      text-decoration: none;
      font-size: 14px;
    }

    .click-btn:hover {
      background: #0056b3;
    }

    .blog-section {
      margin-top: 60px;
    }

    .blog-section h2 {
      font-size: 1.6em;
      margin-bottom: 20px;
      text-align: center;
    }

    .blog-post {
      background: white;
      padding: 15px 20px;
      margin-bottom: 15px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
    }

    .blog-post h3 {
      margin-bottom: 10px;
      font-size: 1.1em;
    }

    .blog-post p {
      font-size: 0.9em;
      color: #444;
    }

    .blog-post a {
      display: inline-block;
      margin-top: 10px;
      color: #007bff;
      text-decoration: none;
      font-weight: bold;
    }
    .search-bar {
      margin: 20px;
      text-align: center;
    }
    .search-bar input {
      padding: 10px;
      width: 60%;
      font-size: 16px;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    .post-card {
      background: #fff;
      margin: 20px;
      padding: 20px;
      border-radius: 16px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .read-more-btn {
      display: inline-block;
      margin-top: 10px;
      padding: 8px 16px;
      background: #007bff;
      color: #fff;
      text-decoration: none;
      border-radius: 8px;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <nav class="sidebar" id="sidebar">
         <h2.0>....</h2.0>
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="blog.php">Blog</a>
    <a href="terms-conditions.php">Terms and Conditions</a>
    <a href="privacy-policy.php">Privacy Policy</a>
  </nav>

  <div class="main">
    <header>
      <h1>Welcome to TOOLOI</h1>
      <p>Your one stop free online tool shop for text, image, PDF, conversion, and developer utilities.</p>
    </header>

    <div class="ad-slot"> <?php include 'ads.php'; ?> </div>

    <div class="tool-grid">
      <div class="category-card">
        <h2>Image Tools</h2>
        <a href="image-tools.php" class="click-btn">Click</a>
      </div>
      <div class="category-card">
        <h2>PDF Tools</h2>
        <a href="pdf-tools.php" class="click-btn">Click</a>
      </div>
      <div class="category-card">
        <h2>Unit & Conversion Tools</h2>
        <a href="unit-tools.php" class="click-btn">Click</a>
      </div>
      <div class="category-card">
        <h2>Developer Tools</h2>
        <a href="developer-tools.php" class="click-btn">Click</a>
      </div>
    </div>

    <div class="ad-slot">  <?php include 'ads.php'; ?> </div>
    <section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;"> ☆● Meet TOOLOI – Your New Best Friend for Free Online Tools! ●☆</h2>
    <p style="margin-bottom: 45px; line-height: 1.7;">
     ---> Say goodbye to complicated software and hello to TOOLOI, your one-stop shop for all the free online tools you could ever need! Whether you’re a creator, developer, student, or just someone looking to get things done faster, our mobile-friendly, secure, and lightning-fast tools are here to make your life easier.
    </p>
 <?php include 'ads.php'; ?> 
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Image Tools: Transform Your Pictures Like a Pro! ●☆</h2>
    <p style="margin-bottom: 45px; line-height: 1.7;">
      --->Our <a href="image-tools.php">Image Tools</a> offer everything you need to enhance and create beautiful visuals! With our <strong>AI-powered Meme Generator</strong> (because who doesn't love a good meme?), <strong>Background Remover</strong>, <strong>Image Compressor</strong>, and <strong>Image Resizer with crop/rotate support</strong>, your social media posts will never be the same.
    </p>
 <?php include 'ads.php'; ?> 
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● PDF Tools: Manage Your PDFs Without the Hassle! ●☆</h2>
    <p style="margin-bottom: 45px; line-height: 1.7;">
      --->No more headaches trying to deal with PDFs! Our <a href="pdf-tools.php">PDF Tools</a> include everything you need, from <strong>PDF to Word Converters</strong> to <strong>PDF Compressors</strong> and even <strong>Word to PDF Converters</strong>. Everything is done online, instantly, and completely free – no annoying sign-ups required!
    </p>
 <?php include 'ads.php'; ?> 
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Unit & Conversion Tools: Math Made Easy! ●☆</h2>
    <p style="margin-bottom: 45px; line-height: 1.7;">
      --->Whether you're dealing with currencies, measurements, or anything in between, our <a href="unit-tools.php">Unit & Conversion Tools</a> are here to save you from the confusion. From <strong>Currency Converters</strong> to <strong>BMI Calculators</strong>, you’ll never have to guess again.
    </p>
 <?php include 'ads.php'; ?> 
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Developer Tools: Code Like a Pro! ●☆</h2>
    <p style="margin-bottom: 45px; line-height: 1.7;">
      --->If you're a developer or student, you’ll love our <a href="developer-tools.php">Developer Tools</a>. We’ve got everything from <strong>HTML/CSS/JS Minifiers</strong> to a <strong>JSON Formatter</strong>, making debugging and testing as easy as pie. (Well, almost.)
    </p>
 <?php include 'ads.php'; ?> 
    <h2 style="font-size:1.8em; margin-bottom: 25px;">☆● Why Choose TOOLOI? ●☆</h2>
    <p style="margin-bottom: 40px; line-height: 1.7;">
      --->Simple – because we're fast, free, and 100% online! No downloads, no registrations, no fuss. We offer tools that are as easy to use as a smartphone app, yet powerful enough to meet your needs. Whether you're Googling for "online image editor", "AI paraphraser", or "free PDF converter", you've found the right place. TOOLOI is your secret weapon for getting things done without the hassle.
    </p>
  </div>
</section>
 <?php include 'ads.php'; ?> 
<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆●Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°~</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Perfect for web development and debugging in a snap!😍🤩</p>
        </div>
      </a>
    </div>

    <!-- Call-to-Action Section -->
    <div style="text-align: center; margin-top: 60px;">
      <a href="index.php" style="background-color: #1a73e8; padding: 15px 40px; color: white; font-size: 1.2em; text-decoration: none; border-radius: 30px; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); transition: background-color 0.3s ease;">
        🥰Explore All Tools🥰
      </a>
    </div>
  </div>
</section>
 <?php include 'ads.php'; ?> 
<!-- Key CSS Animation -->
<style>
  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  .tool-category:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
  }

  .tool-category a {
    text-decoration: none;
  }

  .tool-category i {
    margin-bottom: 15px;
  }
</style> <?php include 'ads.php'; ?> 
        <h2>Recent blog posts </h2>
    <div class="search-bar">
      <input type="text" id="searchInput" placeholder="Search blog posts..." oninput="loadPosts(true)">
    </div>

    <div id="blog-posts"></div>

    <div id="loading" style="text-align:center; padding: 20px;">Loading more posts...</div>

 <?php include 'ads.php'; ?> 
    <footer>
      &copy; 2025 TOOLOI. All rights reserved.
    </footer>
  </div>
  <script>
    let offset = 0;
    let loading = false;
    let searchQuery = '';

    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    function loadPosts(reset = false) {
      if (loading) return;
      loading = true;

      if (reset) {
        offset = 0;
        document.getElementById("blog-posts").innerHTML = '';
        searchQuery = document.getElementById("searchInput").value.trim();
      }

      fetch(`load_posts.php?offset=${offset}&search=${encodeURIComponent(searchQuery)}`)
        .then(res => res.text())
        .then(data => {
          if (data.trim() === '') {
            document.getElementById("loading").innerText = "No more posts.";
          } else {
            document.getElementById("blog-posts").insertAdjacentHTML('beforeend', data);
            offset += 5;
            loading = false;
          }
        });
    }

    // Load initial posts
    window.onload = loadPosts;

    // Infinite scroll
    window.onscroll = function () {
      if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 100) {
        loadPosts();
      }
    };
  </script>
</body>
</html>