<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: admin-login.php");
  exit();
}

require_once 'db.php';

if (isset($_GET['id'])) {
  $id = $_GET['id'];

  $delete = "DELETE FROM posts WHERE id=$id";

  if (mysqli_query($conn, $delete)) {
    echo "<script>alert('Post deleted successfully!'); window.location.href='manage-posts.php';</script>";
  } else {
    echo "Error deleting post: " . mysqli_error($conn);
  }
}
?>