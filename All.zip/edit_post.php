<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: admin-login.php");
  exit();
}
require_once 'db.php';

if (!isset($_GET['id'])) {
  echo "Invalid request.";
  exit();
}

$post_id = $_GET['id'];
$query = "SELECT * FROM posts WHERE id = $post_id";
$result = mysqli_query($conn, $query);
$post = mysqli_fetch_assoc($result);

if (!$post) {
  echo "Post not found.";
  exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Edit Post</title>
  <link rel="stylesheet" href="style.css">
  <style>
    <?php include 'admin_ui.css'; ?>
    .form-wrapper {
      background: white;
      padding: 25px;
      border-radius: 12px;
      max-width: 700px;
      margin: 40px auto;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .form-wrapper input, .form-wrapper textarea {
      width: 100%;
      margin-bottom: 20px;
      padding: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    .form-wrapper button {
      background: #007bff;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 6px;
      cursor: pointer;
    }

    .form-wrapper button:hover {
      background: #0056b3;
    }
     
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      color: #222;
    }

    .menu-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 8px 12px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0;
      left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    .main {
      padding: 70px 20px 20px 240px;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    header h1 {
      font-size: 2em;
    }

    .dashboard-links {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-top: 30px;
    }

    .dash-card {
      background: white;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      text-align: center;
      transition: 0.3s;
    }

    .dash-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.15);
    }

    .dash-card a {
      display: inline-block;
      margin-top: 10px;
      background: #007bff;
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 6px;
    }

    .dash-card a:hover {
      background: #0056b3;
    }
    
    .footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }
  </style>
</head>
<body>

<button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

<div class="sidebar" id="sidebar">
  <h2>Admin Panel</h2>
  <a href="admin-dashboard.php">Dashboard</a>
  <a href="add-post.php">Add Post</a>
  <a href="manage-posts.php">Manage Posts</a>
  <a href="logout.php">Logout</a>
</div>

<div class="main">
  <header><h1>Edit Blog Post</h1></header>

  <div class="form-wrapper">
    <form action="process_edit_post.php" method="POST" enctype="multipart/form-data">
      <input type="hidden" name="id" value="<?php echo $post['id']; ?>">

      <label>Title:</label>
      <input type="text" name="title" value="<?php echo htmlspecialchars($post['title']); ?>" required>

      <label>Content:</label>
      <textarea name="content" rows="10"><?php echo htmlspecialchars($post['content']); ?></textarea>

      <label>Change Image (optional):</label>
      <input type="file" name="image">

      <button type="submit" name="submit">Update Post</button>
    </form>
  </div>
</div>

<script>
  function toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("open");
  }
</script>

</body>
</html>