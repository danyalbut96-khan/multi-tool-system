<?php
include 'db.php';
header('Content-Type: application/json');

$filter = $_GET['filter'] ?? '7d';

$conditions = "";
switch ($filter) {
  case 'live':
    $conditions = "AND visit_time >= NOW() - INTERVAL 5 MINUTE";
    break;
  case '24h':
    $conditions = "AND visit_time >= NOW() - INTERVAL 1 DAY";
    break;
  case '7d':
    $conditions = "AND visit_time >= NOW() - INTERVAL 7 DAY";
    break;
  case '30d':
    $conditions = "AND visit_time >= NOW() - INTERVAL 30 DAY";
    break;
  case '1y':
    $conditions = "AND visit_time >= NOW() - INTERVAL 1 YEAR";
    break;
  case 'lifetime':
    $conditions = "";
    break;
}

// Views Over Time (line chart)
$views_sql = "SELECT DATE(visit_time) as day, COUNT(*) as count
              FROM visitors
              WHERE 1 $conditions
              GROUP BY day
              ORDER BY day ASC";
$views_result = $conn->query($views_sql);
$views = ['labels' => [], 'data' => []];
while ($row = $views_result->fetch_assoc()) {
  $views['labels'][] = $row['day'];
  $views['data'][] = (int)$row['count'];
}

// Referrers (pie chart)
$referrer_sql = "SELECT page, COUNT(*) as count FROM visitors WHERE 1 $conditions GROUP BY page ORDER BY count DESC LIMIT 5";
$ref_result = $conn->query($referrer_sql);
$referrers = ['labels' => [], 'data' => []];
while ($row = $ref_result->fetch_assoc()) {
  $referrers['labels'][] = $row['page'] ?: 'Direct';
  $referrers['data'][] = (int)$row['count'];
}

// Top Countries (map + table)
$country_sql = "SELECT country, COUNT(*) as count FROM visitors WHERE 1 $conditions GROUP BY country ORDER BY count DESC LIMIT 10";
$country_result = $conn->query($country_sql);
$countries = [];

// Sample static lat/lon — ideally use a proper geolocation DB
$country_coords = [
  'United States' => ['lat' => 37.0902, 'lon' => -95.7129],
  'India' => ['lat' => 20.5937, 'lon' => 78.9629],
  'Pakistan' => ['lat' => 30.3753, 'lon' => 69.3451],
  'United Kingdom' => ['lat' => 55.3781, 'lon' => -3.4360],
  'Germany' => ['lat' => 51.1657, 'lon' => 10.4515],
  'Canada' => ['lat' => 56.1304, 'lon' => -106.3468],
  'Bangladesh' => ['lat' => 23.6850, 'lon' => 90.3563],
  'Australia' => ['lat' => -25.2744, 'lon' => 133.7751],
  'France' => ['lat' => 46.2276, 'lon' => 2.2137],
  'Brazil' => ['lat' => -14.2350, 'lon' => -51.9253]
];

while ($row = $country_result->fetch_assoc()) {
  $country = $row['country'] ?: 'Unknown';
  $coords = $country_coords[$country] ?? ['lat' => null, 'lon' => null];
  $countries[] = [
    'country' => $country,
    'count' => (int)$row['count'],
    'lat' => $coords['lat'],
    'lon' => $coords['lon']
  ];
}

// Final Output
echo json_encode([
  'views' => $views,
  'referrers' => $referrers,
  'top_countries' => $countries
]);
?>