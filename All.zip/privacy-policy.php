<?php include 'visitor_tracker.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="title" content="Privacy Policy - TOOLOI">
  <meta name="description" content="Learn how TOOLOI collects, uses, and protects your data. Your privacy matters to us.">
  <meta name="keywords" content="privacy policy, data collection, online tools, TOOLOI privacy">
  <meta name="author" content="TOOLOI Team">
  <title>Privacy Policy - TOOLOI</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', sans-serif; background: #f5f7fa; color: #222; }
    .menu-btn {
      position: fixed; top: 15px; left: 15px; z-index: 1001;
      background: #007bff; color: white; padding: 10px 15px;
      border: none; border-radius: 5px; cursor: pointer;
    }
    .sidebar {
      position: fixed; top: 0; left: 0; width: 220px; height: 100%;
      background: #007bff; color: white; padding: 20px;margin-top:50px;
      transform: translateX(-100%); transition: transform 0.3s ease;
      z-index: 1000;
    }
    .sidebar.open { transform: translateX(0); }
    .sidebar a {
      display: block; color: white; text-decoration: none;
      margin: 15px 0; font-size: 1.1em;
    }
    .main { padding: 70px 20px 20px; }
    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white; padding: 30px 20px; text-align: center;
    }
    header h1 { font-size: 2.2em; }
    h2 { margin-top: 30px; font-size: 1.5em; }
    p, li { margin-top: 10px; line-height: 1.6; }
    footer {
      text-align: center; padding: 30px 0;
      margin-top: 40px; background: #f0f0f0;
    }
  </style>
</head>
<body>
  <div class="sidebar" id="sidebar">
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="blog.php">Blog</a>
    <a href="terms-conditions.php">Terms & Conditions</a>
  </div>

  <button class="menu-btn" onclick="toggleSidebar()">Menu</button>

  <header>
    <h1>Privacy Policy</h1>
  </header>

  <div class="main">
    <p>At <strong>TOOLOI</strong>, we respect your privacy. This policy explains what data we collect, how we use it, and how your privacy is protected.</p>

    <h2>1. What We Collect</h2>
    <p>We may collect basic non-personal data like your device type, browser, country, and pages visited. This is done through analytics tools to help us improve user experience.</p>

    <h2>2. How We Use Your Data</h2>
    <ul>
      <li>To understand how visitors use our tools</li>
      <li>To improve tool functionality and performance</li>
      <li>To detect and prevent misuse or spam</li>
    </ul>

    <h2>3. Cookies & Tracking</h2>
    <p>We use cookies to remember preferences and enhance your visit. Cookies are small text files stored on your browser. You can disable them in your browser settings.</p>

    <h2>4. Third-Party Services</h2>
    <p>We may use services like Google Analytics or API providers. These services may also collect anonymized usage data for improving tool performance.</p>

    <h2>5. Data Protection</h2>
    <p>We take reasonable steps to secure your information and prevent unauthorized access. However, no online system is 100% secure.</p>

    <h2>6. Your Rights</h2>
    <p>You have the right to know what data we store, to request its deletion, or to ask for changes. Simply contact us for any privacy-related requests.</p>

    <h2>7. Updates to This Policy</h2>
    <p>We may update this policy from time to time. We recommend reviewing it periodically. Your continued use of the site means you accept the current version.</p>
  </div>

  <footer>
    <p>&copy; 2025 TOOLOI. All rights reserved.</p>
  </footer>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }
  </script>
</body>
</html>