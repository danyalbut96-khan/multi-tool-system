<?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Image to Text - TOOLOI</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Segoe+UI&display=swap" />
  <script src="https://cdn.jsdelivr.net/npm/tesseract.js@2/dist/tesseract.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      padding: 20px;
      text-align: center;
    }

    .menu-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 50px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    .drop-area {
      border: 2px dashed #007bff;
      border-radius: 10px;
      padding: 30px;
      margin: 20px auto;
      max-width: 500px;
      color: #555;
      cursor: pointer;
    }

    .drop-area.dragover {
      background-color: #e0f0ff;
    }

    img {
      max-width: 100%;
      margin-top: 20px;
    }

    textarea {
      width: 90%;
      max-width: 600px;
      height: 200px;
      margin-top: 20px;
      padding: 10px;
      font-size: 1em;
    }

    select, button {
      margin: 10px;
      padding: 10px 15px;
      font-size: 1em;
    }

    .ad-slot {
      margin: 40px 0;
      background: #eaeaea;
      padding: 30px;
      text-align: center;
      border: 2px dashed #ccc;
      color: #666;
      font-style: italic;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }

    .loader {
      display: none;
      margin-top: 20px;
    }

    .loader div {
      width: 15px;
      height: 15px;
      background: #007bff;
      border-radius: 50%;
      display: inline-block;
      animation: bounce 1.4s infinite ease-in-out both;
    }

    .loader div:nth-child(1) { animation-delay: -0.32s; }
    .loader div:nth-child(2) { animation-delay: -0.16s; }

    @keyframes bounce {
      0%, 80%, 100% { transform: scale(0); }
      40% { transform: scale(1); }
    }
  </style>
</head>
<body>

  <!-- Menu Button -->
  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <!-- Sidebar -->
  <nav class="sidebar" id="sidebar">
    <h2></h2>
    <a href="https://tooloi.earningera.com/index.php">Home</a>
    <a href="https://tooloi.earningera.com/about.php">About</a>
    <a href="https://tooloi.earningera.com/image-tools.php">Image Tools</a>
  </nav>

  <!-- Header -->
  <header>
    <h1>Image to Text Converter</h1>
    <p>Extract text from images easily</p>
  </header>
 <div class="ad-slot"> <?php include 'ads.php'; ?> </div>


  <!-- Drop Area -->
  <div class="drop-area" id="dropArea">
    Click or drag an image here
    <input type="file" id="imageInput" accept="image/*" hidden>
  </div>

  <img id="previewImg" />
  
  <div>
    <label for="lang">Select Language:</label>
    <select id="lang">
      <option value="auto">Auto Detect</option>
      <option value="eng">English</option>
      <option value="hin">Hindi</option>
      <option value="spa">Spanish</option>
      <option value="fra">French</option>
      <option value="deu">German</option>
      <option value="ita">Italian</option>
    </select>
    <button onclick="extractText()">Extract Text</button>
    <button onclick="saveAsPDF()">Save as PDF</button>
  </div>

  <!-- Loading Animation -->
  <div class="loader" id="loader">
    <div></div><div></div><div></div>
  </div>

  <!-- Output Text -->
  <textarea id="outputText" placeholder="Extracted text will appear here..."></textarea>
  <?php include 'ads.php'; ?>  <section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Image Tools – Your Ultimate Visual Toolkit ●☆</h2> <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Say hello to stunning visuals and goodbye to boring, unedited images! TOOLOI's <a href="image-tools.php"><strong>Image Tools</strong></a> are your all-in-one solution for turning ordinary pictures into eye-catching masterpieces—no software, no hassle, just pure magic from your browser!
    </p>
    
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Meme Generator:</strong> Our AI-powered Meme Generator is perfect for creating viral-worthy memes. Add text, emojis, drag & drop to position, customize fonts, and colors – all in real-time with live preview. Whether it's for fun or marketing, we've got your meme game covered.
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Background Remover:</strong> Instantly remove backgrounds from your photos with a single click. Perfect for product photos, profile pics, and design projects—no Photoshop needed. Our smart AI does the heavy lifting so you can focus on creativity.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Image Compressor:</strong> Compress images without losing quality. Whether it’s PNG, JPG, or WebP, our tool ensures your files are optimized for web and mobile—great for faster loading websites and sharing on platforms.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Image Resizer (with Crop & Rotate):</strong> Resize multiple images in one go, lock aspect ratio, set output quality, and preview before downloading. You can also crop, rotate, rename, and batch process—all in your browser, with full control.
    </p>

    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Whether you're a designer, student, business owner, or meme-lover, TOOLOI’s image tools are crafted to save you time and deliver professional results. Try them now and watch your images go from “meh” to “wow”!
    </p>
  </div>
</section>
 <?php include 'ads.php'; ?> 
<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆● Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Format, minify, and test your code like a pro😍🤩.</p>
        </div>
      </a>
    </div>
  </div>
</section>

  <div class="ad-slot"> <?php include 'ads.php'; ?> </div>

  <footer>© 2025 TOOLOI - All Rights Reserved</footer>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    const dropArea = document.getElementById('dropArea');
    const imageInput = document.getElementById('imageInput');
    let originalFile = null;

    dropArea.addEventListener('click', () => imageInput.click());
    dropArea.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropArea.classList.add('dragover');
    });
    dropArea.addEventListener('dragleave', () => {
      dropArea.classList.remove('dragover');
    });
    dropArea.addEventListener('drop', (e) => {
      e.preventDefault();
      dropArea.classList.remove('dragover');
      originalFile = e.dataTransfer.files[0];
      previewImage(originalFile);
    });
    imageInput.addEventListener('change', () => {
      originalFile = imageInput.files[0];
      previewImage(originalFile);
    });

    function previewImage(file) {
      const reader = new FileReader();
      reader.onload = () => {
        document.getElementById('previewImg').src = reader.result;
      };
      reader.readAsDataURL(file);
    }

    function extractText() {
      const output = document.getElementById('outputText');
      const loader = document.getElementById('loader');
      if (!originalFile) return alert("Please select an image first.");

      const langSelect = document.getElementById("lang");
      const lang = langSelect.value;
      const useAuto = lang === "auto";
      const langCode = useAuto ? "eng+hin+spa+fra+deu+ita" : lang;

      output.value = "";
      loader.style.display = "block";

      Tesseract.recognize(originalFile, langCode, {
        logger: m => console.log(m)
      }).then(({ data }) => {
        loader.style.display = "none";
        output.value = data.text.trim() || "No text detected.";
        if (useAuto) output.value += `\n\n(Detected using: ${langCode})`;
      }).catch(err => {
        loader.style.display = "none";
        output.value = "Error: " + err.message;
      });
    }

    function saveAsPDF() {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      const text = document.getElementById('outputText').value;
      if (!text) return alert("No text to save.");
      const lines = doc.splitTextToSize(text, 180);
      doc.text(lines, 10, 10);
      doc.save("extracted-text.pdf");
    }
  </script>

</body>
</html>