<?php include 'visitor_tracker.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Image Resizer - TOOLOI</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Segoe+UI&display=swap"/>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      color: #222;
    }

    .menu-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    main {
      padding: 70px 20px 20px;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    .ad-slot {
      margin: 40px 0;
      background: #eaeaea;
      padding: 30px;
      text-align: center;
      border: 2px dashed #ccc;
      color: #666;
      font-style: italic;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }

    .resizer-box {
      max-width: 700px;
      margin: auto;
      background: white;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      text-align: center;
    }

    .resizer-box input, .resizer-box select {
      margin: 10px;
      padding: 10px;
    }

    .output-preview img {
      max-width: 100%;
      border: 1px solid #ccc;
      margin-bottom: 10px;
      border-radius: 8px;
    }

    .resizer-box button {
      background: #007bff;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .resizer-box button:hover {
      background: #0056b3;
    }

    .output-preview {
      margin-top: 30px;
    }
  </style>
</head>
<body>
  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>
  <nav class="sidebar" id="sidebar">
    <h2></h2>
    <a href="https://tooloi.earningera.com/index.php">Home</a>
    <a href="https://tooloi.earningera.com/about.php">About</a>
       <a href="https://tooloi.earningera.com/image-tools.php">Image Tools</a>
    
  </nav>

  <header>
    <h1>Image Resizer</h1>
    <p>Resize, crop, rotate & preview multiple images before download.</p>
  </header>

  <main>
    <div class="ad-slot"> <?php include 'ads.php'; ?> </div>

    <div class="resizer-box">
      <input type="file" id="resizeInput" multiple accept="image/*"><br>
      Width: <input type="number" id="resizeWidth" value="300">
      Height: <input type="number" id="resizeHeight" value="300"><br>
      <label><input type="checkbox" id="lockAspect" checked> Lock Aspect Ratio</label><br>
      Rotate: <input type="number" id="rotateDeg" value="0" step="90" min="0" max="360"> deg<br>
      Format:
      <select id="formatSelect">
        <option value="jpeg">JPG</option>
        <option value="png">PNG</option>
        <option value="webp">WebP</option>
      </select><br>
      Quality: <input type="range" id="qualitySlider" min="0.1" max="1" step="0.1" value="0.9"><span id="qualityValue">0.9</span><br>
      <button onclick="resizeImages()">Resize Images</button>
    </div>

    <div class="output-preview" id="previewArea"></div> <?php include 'ads.php'; ?> 
    <section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Image Tools – Your Ultimate Visual Toolkit ●☆</h2> <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Say hello to stunning visuals and goodbye to boring, unedited images! TOOLOI's <a href="image-tools.php"><strong>Image Tools</strong></a> are your all-in-one solution for turning ordinary pictures into eye-catching masterpieces—no software, no hassle, just pure magic from your browser!
    </p>
    
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Meme Generator:</strong> Our AI-powered Meme Generator is perfect for creating viral-worthy memes. Add text, emojis, drag & drop to position, customize fonts, and colors – all in real-time with live preview. Whether it's for fun or marketing, we've got your meme game covered.
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Background Remover:</strong> Instantly remove backgrounds from your photos with a single click. Perfect for product photos, profile pics, and design projects—no Photoshop needed. Our smart AI does the heavy lifting so you can focus on creativity.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Image Compressor:</strong> Compress images without losing quality. Whether it’s PNG, JPG, or WebP, our tool ensures your files are optimized for web and mobile—great for faster loading websites and sharing on platforms.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Image Resizer (with Crop & Rotate):</strong> Resize multiple images in one go, lock aspect ratio, set output quality, and preview before downloading. You can also crop, rotate, rename, and batch process—all in your browser, with full control.
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Whether you're a designer, student, business owner, or meme-lover, TOOLOI’s image tools are crafted to save you time and deliver professional results. Try them now and watch your images go from “meh” to “wow”!
    </p>
  </div>
</section>
 <?php include 'ads.php'; ?> 
<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆● Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Format, minify, and test your code like a pro😍🤩.</p>
        </div>
      </a>
    </div>
  </div>
</section> <?php include 'ads.php'; ?> 
  </main>
 <div class="ad-slot"> <?php include 'ads.php'; ?> </div>


  <footer>
    &copy; 2025 TOOLOI - All rights reserved.
  </footer>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    document.getElementById("qualitySlider").oninput = function () {
      document.getElementById("qualityValue").innerText = this.value;
    }

    function resizeImages() {
      const files = document.getElementById("resizeInput").files;
      const widthInput = document.getElementById("resizeWidth");
      const heightInput = document.getElementById("resizeHeight");
      const rotateDeg = parseInt(document.getElementById("rotateDeg").value) || 0;
      const lockAspect = document.getElementById("lockAspect").checked;
      const format = document.getElementById("formatSelect").value;
      const quality = parseFloat(document.getElementById("qualitySlider").value);
      let mimeType = "image/jpeg";
      if (format === "png") mimeType = "image/png";
      else if (format === "webp") mimeType = "image/webp";

      const preview = document.getElementById("previewArea");
      preview.innerHTML = "";

      Array.from(files).forEach((file, index) => {
        const reader = new FileReader();
        reader.onload = function(e) {
          const img = new Image();
          img.src = e.target.result;

          img.onload = function() {
            let newWidth = parseInt(widthInput.value);
            let newHeight = parseInt(heightInput.value);
            const aspect = img.width / img.height;

            if (lockAspect) {
              if (img.width > img.height) {
                newHeight = Math.round(newWidth / aspect);
              } else {
                newWidth = Math.round(newHeight * aspect);
              }
            }

            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");

            if (rotateDeg === 90 || rotateDeg === 270) {
              canvas.width = newHeight;
              canvas.height = newWidth;
            } else {
              canvas.width = newWidth;
              canvas.height = newHeight;
            }

            ctx.save();
            if (rotateDeg) {
              ctx.translate(canvas.width / 2, canvas.height / 2);
              ctx.rotate(rotateDeg * Math.PI / 180);
              ctx.drawImage(img, -newWidth / 2, -newHeight / 2, newWidth, newHeight);
            } else {
              ctx.drawImage(img, 0, 0, newWidth, newHeight);
            }
            ctx.restore();

            const dataUrl = canvas.toDataURL(mimeType, quality);
            const outImg = document.createElement("img");
            outImg.src = dataUrl;

            const downloadLink = document.createElement("a");
            downloadLink.href = dataUrl;
            downloadLink.download = `resized_${index + 1}.${format}`;
            downloadLink.textContent = `Download Image ${index + 1}`;

            const wrapper = document.createElement("div");
            wrapper.appendChild(outImg);
            wrapper.appendChild(document.createElement("br"));
            wrapper.appendChild(downloadLink);
            wrapper.style.marginBottom = "30px";

            preview.appendChild(wrapper);
          };
        };
        reader.readAsDataURL(file);
      });
    }
  </script>
</body>
</html>