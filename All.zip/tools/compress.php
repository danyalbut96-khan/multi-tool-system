<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $quality = isset($_POST['quality']) ? intval($_POST['quality']) : 60;
    $original = $_FILES['image']['tmp_name'];

    $imageInfo = getimagesize($original);
    $mime = $imageInfo['mime'];

    $filename = time() . '.jpg';
    $outputPath = "tools/compressed/" . $filename;

    if ($mime === 'image/jpeg') {
        $image = imagecreatefromjpeg($original);
        imagejpeg($image, $outputPath, $quality);
    } elseif ($mime === 'image/png') {
        $image = imagecreatefrompng($original);
        imagejpeg($image, $outputPath, $quality); // Convert to JPEG for compression
    } elseif ($mime === 'image/webp') {
        $image = imagecreatefromwebp($original);
        imagejpeg($image, $outputPath, $quality);
    } else {
        http_response_code(400);
        echo "Unsupported file type.";
        exit;
    }

    header('Content-Type: image/jpeg');
    readfile($outputPath);
    imagedestroy($image);
}
?>