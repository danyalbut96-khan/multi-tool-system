<?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Merge PDFs - TOOLOI</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Segoe+UI&display=swap" />
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      padding: 20px;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    .menu-btn {
  position: fixed;
  top: 10px;
  left: 10px;
  z-index: 1001;
  background: #007bff;
  color: white;
  padding: 4px 8px;
  font-size: 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  width: auto;
  height: auto;
  line-height: 1;
}
    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    main {
      max-width: 600px;
      margin: auto;
      padding: 70px 20px 20px;
      text-align: center;
    }

    input[type="file"], button {
      margin-top: 10px;
      width: 100%;
      padding: 10px;
      font-size: 1em;
      border-radius: 5px;
      border: none;
    }

    button {
      background: #007bff;
      color: white;
      cursor: pointer;
    }

    button:hover {
      background: #0056b3;
    }

    .ad-slot {
      margin: 40px 0;
      background: #eaeaea;
      padding: 30px;
      text-align: center;
      border: 2px dashed #ccc;
      color: #666;
      font-style: italic;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }

    .loading-spinner {
      display: none;
      border: 4px solid #f3f3f3;
      border-top: 4px solid #007bff;
      border-radius: 50%;
      width: 50px;
      height: 50px;
      animation: spin 2s linear infinite;
      margin-top: 20px;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .hidden {
      display: none;
    }

    #mergeResultButtons {
      margin-top: 20px;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <nav class="sidebar" id="sidebar">
    <h2></h2>
    <a href="https://tooloi.earningera.com/index.php">Home</a>
    <a href="https://tooloi.earningera.com/about.php">About</a>
        <a href="https://tooloi.earningera.com/pdf-tools.php">Pdf Tools</a>

  </nav>

  <header>
    <h1>Merge PDFs</h1>
    <p>Merge multiple PDF files into one.</p>
  </header>
 <div class="ad-slot"> <?php include 'ads.php'; ?> </div>
  <main>
    <input type="file" id="pdfUpload" accept="application/pdf" multiple />
    <button onclick="mergePDFs()">Merge PDFs</button>
    
    <!-- Loading spinner -->
    <div id="loadingSpinner" class="loading-spinner"></div>

    <div id="mergeResultButtons" class="hidden">
      <button id="previewButton" onclick="previewPDF()">Preview PDF</button>
      <button id="downloadButton" onclick="downloadPDF()">Download PDF</button>
    </div>

    <div class="ad-slot"> <?php include 'ads.php'; ?> </div>
    <section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● PDF Tools – Simplify Your Digital Paperwork ●☆</h2> <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Tired of juggling multiple PDF tasks? TOOLOI's <a href="pdf-tools.php"><strong>PDF Tools</strong></a> are your go-to solution for handling documents quickly and efficiently—no downloads, no stress. Just upload your files and let our smart tools do the rest!
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ PDF Merger:</strong> Merge multiple PDF files into a single, organized document in seconds. Perfect for contracts, reports, eBooks, or study materials. Our <strong>free online PDF merger</strong> keeps your formatting intact and your workflow smooth.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ PDF Splitter:</strong> Need just one page or a section from a big PDF? Our <strong>PDF splitter tool</strong> lets you extract pages easily. Whether you’re creating handouts or splitting chapters, you’re in full control—fast, accurate, and secure.
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ PDF Compressor:</strong> Reduce PDF file size without compromising quality. Ideal for emailing documents, uploading resumes, or saving storage. Our <strong>online PDF compressor</strong> ensures fast uploads and lightning-fast downloads.
    </p>

    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Whether you're a student, professional, or casual user, TOOLOI’s <strong>free online PDF tools</strong> save time, reduce file bloat, and make document management a breeze. Try them now and take control of your PDFs like never before!
    </p>
  </div>
</section>
 <?php include 'ads.php'; ?> 
<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆● Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Format, minify, and test your code like a pro😍🤩.</p>
        </div>
      </a>
    </div>
  </div>
</section>
  </main>
 <?php include 'ads.php'; ?> 
  <footer>
    &copy; 2025 TOOLOI. All rights reserved.
  </footer>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js"></script>
  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    let mergedPdfBytes = null; // This will hold the merged PDF bytes

    async function mergePDFs() {
      const fileInput = document.getElementById('pdfUpload');
      const files = fileInput.files;

      if (files.length < 2) {
        alert("Please upload at least two PDF files to merge.");
        return;
      }

      // Show loading spinner
      document.getElementById("loadingSpinner").style.display = "inline-block";

      const pdfDocs = [];

      // Load all uploaded PDF files into PDF-lib
      for (let i = 0; i < files.length; i++) {
        const arrayBuffer = await files[i].arrayBuffer();
        const pdfDoc = await PDFLib.PDFDocument.load(arrayBuffer);
        pdfDocs.push(pdfDoc);
      }

      // Create a new PDF document to hold the merged files
      const mergedPdf = await PDFLib.PDFDocument.create();

      // Copy pages from each document
      for (const pdfDoc of pdfDocs) {
        const copiedPages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPages().map((_, index) => index));
        copiedPages.forEach((page) => mergedPdf.addPage(page));
      }

      mergedPdfBytes = await mergedPdf.save();

      // Hide the loading spinner and show preview & download buttons
      document.getElementById("loadingSpinner").style.display = "none";
      document.getElementById("mergeResultButtons").style.display = "inline-block";
    }

    function previewPDF() {
      const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
    }

    function downloadPDF() {
      const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'merged-pdf.pdf';
      link.click();
    }
  </script>

</body>
</html>