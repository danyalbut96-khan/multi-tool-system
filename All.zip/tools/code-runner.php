<?php include 'visitor_tracker.php'; ?><?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Code Runner - TOOLOI</title>
  <link rel="stylesheet" href="https://tooloi.earningera.com/style.css" />
  <style>
    /* Apply the global styles from your homepage */
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      color: #222;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .menu-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 40px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    /* Header */
    header {
      padding: 2rem 1rem;
      text-align: center;
      background: #007bff; /* Match homepage header color */
      color: white;
    }
    header h1 {
      font-size: 36px; /* Adjust size to match homepage */
    }
    header p {
      font-size: 18px;
    }
    /* Main Content Area */
    .main {
      padding: 1rem;
      max-width: 900px;
      margin: auto;
    }
    /* Tool Card */
    .tool-card {
      background: white;
      padding: 1rem;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      margin-bottom: 2rem;
    }
    .input-section {
      display: flex;
      justify-content: space-between;
      margin-bottom: 1rem;
    }
    .input-container {
      width: 30%;
    }
    textarea {
      width: 100%;
      height: 150px;
      font-family: monospace;
      font-size: 0.95rem;
      padding: 10px;
      margin-bottom: 1rem;
      border: 1px solid #ccc;
      border-radius: 8px;
      resize: vertical;
    }
    button {
      background: #007bff;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 1rem;
    }
    button:hover {
      background: #0056b3;
    }
    iframe {
      width: 100%;
      height: 500px;
      border: 1px solid #ccc;
      border-radius: 8px;
      margin-top: 1rem;
      background: white;
    }
    /* Ad Space */
    .ad-slot {
      margin: 2rem 0;
      padding: 1rem;
      text-align: center;
      background: #e4e4e4;
      border-radius: 10px;
    }
    /* Footer */
    footer {
      background: #007bff; /* Match homepage footer color */
      color: #fff;
      text-align: center;
      padding: 1rem;
    }
    .copy-btn {
      background: #28a745;
      margin-top: 10px;
      font-size: 0.9rem;
    }
    .copy-btn:hover {
      background: #218838;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <div class="sidebar" id="sidebar">
       <h2></h2>
    <a href="https://tooloi.earningera.com/index.php">Home</a>
    <a href="https://tooloi.earningera.com/about.php">About</a>
    <a href="https://tooloi.earningera.com/developer-tools.php"> Developer Tools</a>
  </div>

  <header>
    <h1>Code Runner</h1>
    <p>Write and run HTML, CSS, and JavaScript code live</p>
  </header>
 <div class="ad-slot"> <?php include 'ads.php'; ?> </div>
  <div class="main">
    <div class="tool-card">
      <div class="input-section">
        <div class="input-container">
          <h2>HTML</h2>
          <textarea id="htmlCode" placeholder="Enter your HTML here..."></textarea>
          <button class="copy-btn" onclick="copyCode('htmlCode')">Copy HTML</button>
        </div>
        
        <div class="input-container">
          <h2>CSS</h2>
          <textarea id="cssCode" placeholder="Enter your CSS here..."></textarea>
          <button class="copy-btn" onclick="copyCode('cssCode')">Copy CSS</button>
        </div>

        <div class="input-container">
          <h2>JavaScript</h2>
          <textarea id="jsCode" placeholder="Enter your JavaScript here..."></textarea>
          <button class="copy-btn" onclick="copyCode('jsCode')">Copy JS</button>
        </div>
      </div>

      <button onclick="runCode()">Run Code</button>

      <iframe id="outputFrame"></iframe>
    </div>

    <div class="ad-slot">
 <?php include 'ads.php'; ?>
    </div>
  </div>
<section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Developer Tools – Enhance Your Coding Workflow ●☆</h2> <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Need powerful tools to streamline your web development process? TOOLOI’s <a href="developer-tools.php"><strong>Developer Tools</strong></a> provide you with the best solutions for efficient code editing and optimization. Whether you're a beginner or an experienced developer, our tools simplify your coding tasks with precision and speed.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ HTML Code Runner:</strong> Write, test, and execute HTML code instantly with the <strong>HTML Code Runner</strong>. This tool allows you to quickly preview your HTML projects without leaving your browser, helping you work faster and more efficiently.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Code Minifier (HTML, CSS, JS):</strong> Need to reduce your code size for better performance? Our <strong>Code Minifier</strong> helps you compress HTML, CSS, and JavaScript files by removing unnecessary spaces, comments, and characters. It makes your code more efficient and improves page loading speeds, perfect for optimizing your websites and apps.
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Whether you're running HTML code live or minifying your files for faster loading, TOOLOI's <strong>Developer Tools</strong> make web development tasks quicker, easier, and more optimized. Enhance your coding experience with our free online tools!
    </p>
  </div>
</section> <?php include 'ads.php'; ?> 
<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆● Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Format, minify, and test your code like a pro😍🤩.</p>
        </div>
      </a>
    </div>
  </div>
</section> <?php include 'ads.php'; ?> 
  <footer>
    <p>&copy; 2025 TOOLOI. All rights reserved.</p>
  </footer>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    function runCode() {
      const html = document.getElementById('htmlCode').value;
      const css = document.getElementById('cssCode').value;
      const js = document.getElementById('jsCode').value;

      const output = `
        <html>
          <head><style>${css}</style></head>
          <body>${html}<script>${js}<\/script></body>
        </html>
      `;

      const iframe = document.getElementById('outputFrame');
      const doc = iframe.contentDocument || iframe.contentWindow.document;
      doc.open();
      doc.write(output);
      doc.close();
    }

    function copyCode(id) {
      const textArea = document.getElementById(id);
      textArea.select();
      document.execCommand('copy');
      alert('Code copied to clipboard!');
    }
  </script>

</body>
</html>