<?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Currency Converter - TOOLOI</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Segoe+UI&display=swap" />
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      color: #222;
    }

    .menu-btn {
      position: fixed;
      top: 10px;
      left: 10px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 6px 10px;
      font-size: 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      line-height: 1;
    }

    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 50px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    header h1 {
      font-size: 2.2em;
    }

    main {
      padding: 60px 20px;
      max-width: 600px;
      margin: 0 auto;
    }

    input, select {
      width: 100%;
      padding: 12px 15px;
      margin-top: 20px;
      border-radius: 10px;
      border: 1px solid #ccc;
      font-size: 1rem;
      background-color: #fff;
      box-shadow: 0 1px 4px rgba(0,0,0,0.05);
      transition: border-color 0.3s ease;
    }

    input:focus, select:focus {
      border-color: #007bff;
      outline: none;
    }

    button {
      margin-top: 25px;
      padding: 14px 20px;
      font-size: 1rem;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    button:hover {
      background: #0056b3;
    }

    .result {
      margin-top: 25px;
      font-weight: bold;
      font-size: 1.1em;
      text-align: center;
    }

    .ad-slot {
      margin: 40px auto;
      max-width: 600px;
      background: #eaeaea;
      padding: 30px;
      text-align: center;
      border: 2px dashed #ccc;
      color: #666;
      font-style: italic;
      border-radius: 10px;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Manu</button>
  <nav class="sidebar" id="sidebar">
    <h2></h2>
    <a href="https://tooloi.earningera.com/index.php">Home</a>
    <a href="https://tooloi.earningera.com/about.php">About</a>
    <a href="https://tooloi.earningera.com/unit-tools.php">Unit Tools</a>
  </nav>

  <header>
    <h1>Currency Converter</h1>
    <p>Real-time currency exchange</p>
  </header>
 <?php include 'ads.php'; ?> 
  <main>
    <input type="number" id="amount" placeholder="Enter amount" />
    <select id="fromCurrency"></select>
    <select id="toCurrency"></select>
    <button onclick="convertCurrency()">Convert</button>
    <div class="loader" id="loader"></div>
    <div class="result" id="result"></div>

    <div class="ad-slot">
       <?php include 'ads.php'; ?> | Visit <a href="https://tooloi.earningera.com" target="_blank">TOOLOI</a>
    </div><section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Unit & Conversion Tools – Convert with Ease ●☆</h2> <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Need to convert measurements, currencies, or time zones quickly? TOOLOI’s <a href="unit-tools.php"><strong>Unit & Conversion Tools</strong></a> simplify all your conversions in a matter of seconds—no complexity, just fast results!
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Unit Converter:</strong> Convert length, weight, volume, temperature, and more with ease. Whether you're a student or a professional, this tool is a must-have for accurate and fast conversions.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Currency Converter:</strong> Need to convert currencies for your next international trip? Our <strong>Currency Converter</strong> provides real-time exchange rates and simplifies foreign transactions.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Time Zone Converter:</strong> Struggling to schedule a meeting across time zones? The <strong>Time Zone Converter</strong> tool helps you plan meetings, calls, or appointments without confusion, even across different countries!
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Age Calculator:</strong> Find out how old you are in years, months, and days, with the <strong>Age Calculator</strong> tool. It's a simple and fun tool for anyone who needs to calculate age for any purpose.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ BMI Calculator:</strong> Want to know if you’re within a healthy weight range? Our <strong>BMI Calculator</strong> helps track your body mass index based on your height and weight, supporting your health goals.
    </p>

    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Whether you're calculating your BMI, converting units or currencies, or figuring out time zones, TOOLOI's <strong>free online conversion tools</strong> make everything easier, faster, and more accurate!
    </p>
  </div>
</section>
 <?php include 'ads.php'; ?> 
<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆● Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Format, minify, and test your code like a pro😍🤩.</p>
        </div>
      </a>
    </div>
  </div>
</section> <?php include 'ads.php'; ?> 
  </main>

  <footer>
    &copy; 2025 TOOLOI. All rights reserved.
  </footer>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    const fromSelect = document.getElementById('fromCurrency');
    const toSelect = document.getElementById('toCurrency');
    const loader = document.getElementById('loader');
    const resultDiv = document.getElementById('result');

    const apiKey = "fa57673d205d6e465bb53f32";
    const apiUrl = `https://v6.exchangerate-api.com/v6/${apiKey}/latest/USD`;

    async function populateCurrencies() {
      const res = await fetch(apiUrl);
      const data = await res.json();
      const currencies = Object.keys(data.conversion_rates);
      currencies.forEach(currency => {
        const option1 = document.createElement("option");
        option1.value = option1.textContent = currency;
        const option2 = document.createElement("option");
        option2.value = option2.textContent = currency;
        fromSelect.appendChild(option1);
        toSelect.appendChild(option2);
      });
      fromSelect.value = "USD";
      toSelect.value = "INR";
    }

    async function convertCurrency() {
      const amount = parseFloat(document.getElementById('amount').value);
      const from = fromSelect.value;
      const to = toSelect.value;

      if (!amount || amount <= 0) {
        alert("Please enter a valid amount.");
        return;
      }

      loader.style.display = "block";
      resultDiv.textContent = "";

      try {
        const res = await fetch(`https://v6.exchangerate-api.com/v6/${apiKey}/pair/${from}/${to}/${amount}`);
        const data = await res.json();
        loader.style.display = "none";
        resultDiv.textContent = `${amount} ${from} = ${data.conversion_result} ${to}`;
      } catch (err) {
        loader.style.display = "none";
        resultDiv.textContent = "Failed to fetch exchange rate.";
      }
    }

    populateCurrencies();
  </script>
</body>
</html>