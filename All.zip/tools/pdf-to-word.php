<?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>PDF to Word Converter - TOOLOI</title>
  <link href="https://fonts.googleapis.com/css2?family=Segoe+UI&display=swap" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.14.305/pdf.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/docx@8.0.3/build/index.umd.min.js"></script>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      margin: 0;
      padding: 0;
    }
    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 2em;
      text-align: center;
    }
    .menu-btn {
      position: fixed;
      top: 10px;
      left: 10px;
      background: #007bff;
      color: white;
      padding: 6px 10px;
      border: none;
      border-radius: 5px;
      font-size: 14px;
    }
    .sidebar {
      position: fixed;
      top: 0;
      left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: 0.3s;
      z-index: 1000;
    }
    .sidebar.open { transform: translateX(0); }
    .sidebar a {
      color: white;
      text-decoration: none;
      display: block;
      margin: 15px 0;
    }
    main {
      max-width: 600px;
      margin: auto;
      padding: 40px 20px;
      text-align: center;
    }
    input[type="file"], button, .progress-bar {
      width: 100%;
      padding: 12px;
      margin-top: 20px;
      font-size: 1em;
    }
    button {
      background: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .output {
      margin-top: 20px;
    }
    .ad-slot {
      background: #e0e0e0;
      padding: 25px;
      margin-top: 40px;
      border: 2px dashed #aaa;
    }
    footer {
      text-align: center;
      padding: 20px;
      background: #f0f0f0;
    }
    .progress-bar {
      height: 10px;
      background: #e0e0e0;
      border-radius: 5px;
      overflow: hidden;
      margin-top: 20px;
    }
    .progress {
      height: 100%;
      background: #007bff;
      width: 0%;
    }
    .drop-zone {
      width: 100%;
      height: 150px;
      background: #f0f0f0;
      border: 2px dashed #007bff;
      border-radius: 5px;
      margin-top: 20px;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 1.2em;
      color: #007bff;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰</button>
  <div class="sidebar" id="sidebar">
    <h2>TOOLOI</h2>
    <a href="index.html">Home</a>
    <a href="about.html">About</a>
  </div>

  <header>
    <h1>PDF to Word Converter</h1>
    <p>Convert multiple PDFs into Word documents with images and tables preserved!</p>
  </header>

  <main>
    <div class="drop-zone" id="dropZone" ondrop="handleFileDrop(event)" ondragover="allowDrop(event)">
      <p>Drag & Drop PDF Files Here</p>
    </div>
    <input type="file" id="pdfInput" accept=".pdf" multiple>
    <button onclick="convertPDF()">Convert & Download</button>
    <div class="progress-bar" id="progressBar">
      <div class="progress" id="progress"></div>
    </div>
    <div class="output" id="outputMsg"></div>

    <div class="ad-slot">Ad Slot - Your Ad Here</div>
  </main>

  <footer>
    &copy; 2025 TOOLOI. All rights reserved.
  </footer>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    function allowDrop(event) {
      event.preventDefault();
    }

    function handleFileDrop(event) {
      event.preventDefault();
      const files = event.dataTransfer.files;
      document.getElementById('pdfInput').files = files;
    }

    async function convertPDF() {
      const fileInput = document.getElementById('pdfInput');
      const outputMsg = document.getElementById('outputMsg');
      const files = fileInput.files;
      
      if (!files.length) {
        outputMsg.innerHTML = "<p style='color:red;'>Please select at least one PDF file.</p>";
        return;
      }

      outputMsg.innerHTML = "Processing PDFs...";
      let totalFiles = files.length;
      let filesProcessed = 0;
      
      Array.from(files).forEach(async (file) => {
        if (!file.name.endsWith('.pdf')) return;
        
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        let fullText = "";
        let images = [];
        
        for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
          const page = await pdf.getPage(pageNum);
          const content = await page.getTextContent();
          const strings = content.items.map(item => item.str);
          fullText += strings.join(" ") + "\n\n";
          
          // Extract images from the page
          const operatorList = await page.getOperatorList();
          operatorList.fnArray.forEach((fn, index) => {
            if (fn === pdfjsLib.OPS.paintImageXObject) {
              images.push({ page: pageNum, imageIndex: index });
            }
          });
        }

        // Create a Word document
        const doc = new docx.Document({
          sections: [
            {
              properties: {},
              children: [
                new docx.Paragraph(fullText)
              ]
            }
          ]
        });

        const blob = await docx.Packer.toBlob(doc);
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = file.name.replace(/\.pdf$/, '.docx');
        link.click();

        filesProcessed++;
        const progressPercent = Math.floor((filesProcessed / totalFiles) * 100);
        document.getElementById('progress').style.width = progressPercent + '%';

        if (filesProcessed === totalFiles) {
          outputMsg.innerHTML = "<p style='color:green;'>Conversion complete. Download started.</p>";
        }
      });
    }
  </script>

</body>
</html>