<?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Age Calculator - TOOLOI</title>
  <link rel="stylesheet" href="https://tooloi.earningera.com/style.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      color: #222;
    }

    .menu-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    .main {
      padding: 70px 20px 20px;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    header h1 {
      font-size: 2.2em;
    }

    .tool-card {
      max-width: 600px;
      margin: 30px auto;
      background: white;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      text-align: center;
    }

    .person-block {
      border: 1px dashed #ccc;
      padding: 15px;
      margin-top: 20px;
      border-radius: 8px;
    }

    .tool-card input {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 1rem;
    }

    .tool-card button {
      margin: 10px 5px 0;
      padding: 12px 20px;
      font-size: 1rem;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .tool-card button:hover {
      background: #0056b3;
    }

    .result {
      margin-top: 20px;
      text-align: left;
    }

    .ad-slot {
      margin: 40px auto;
      max-width: 600px;
      background: #eaeaea;
      padding: 30px;
      text-align: center;
      border: 2px dashed #ccc;
      color: #666;
      font-style: italic;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <div class="sidebar" id="sidebar">
    <h2></h2>
    <a href="https://tooloi.earningera.com/index.php">Home</a>
    <a href="https://tooloi.earningera.com/about.php">About</a>
        <a href="https://tooloi.earningera.com/unit-tools.php">Unit Tools</a>
  
  </div>

  <header>
    <h1>Age Calculator</h1>
    <p>Calculate and compare exact age for multiple people</p>
  </header>
 <?php include 'ads.php'; ?> 
  <div class="main">
    <div class="tool-card">
      <div id="peopleContainer"></div>

      <button onclick="addPerson()">+ Add Person</button>
      <button onclick="calculateAll()">Calculate All</button>
      <button onclick="downloadCertificates()">Download TXT</button>
      <button onclick="shareAges()">Share</button>
      <button onclick="exportToExcel()">Export to Excel</button>
      <button onclick="downloadPDF()">Download as PDF</button>

      <div class="result" id="resultArea"></div>
    </div>

    <div class="ad-slot">
       <?php include 'ads.php'; ?> 
    </div>
    <section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Unit & Conversion Tools – Convert with Ease ●☆</h2> <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Need to convert measurements, currencies, or time zones quickly? TOOLOI’s <a href="unit-tools.php"><strong>Unit & Conversion Tools</strong></a> simplify all your conversions in a matter of seconds—no complexity, just fast results!
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Unit Converter:</strong> Convert length, weight, volume, temperature, and more with ease. Whether you're a student or a professional, this tool is a must-have for accurate and fast conversions.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Currency Converter:</strong> Need to convert currencies for your next international trip? Our <strong>Currency Converter</strong> provides real-time exchange rates and simplifies foreign transactions.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Time Zone Converter:</strong> Struggling to schedule a meeting across time zones? The <strong>Time Zone Converter</strong> tool helps you plan meetings, calls, or appointments without confusion, even across different countries!
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Age Calculator:</strong> Find out how old you are in years, months, and days, with the <strong>Age Calculator</strong> tool. It's a simple and fun tool for anyone who needs to calculate age for any purpose.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ BMI Calculator:</strong> Want to know if you’re within a healthy weight range? Our <strong>BMI Calculator</strong> helps track your body mass index based on your height and weight, supporting your health goals.
    </p>

    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Whether you're calculating your BMI, converting units or currencies, or figuring out time zones, TOOLOI's <strong>free online conversion tools</strong> make everything easier, faster, and more accurate!
    </p>
  </div>
</section>
 <?php include 'ads.php'; ?> 
<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆● Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Format, minify, and test your code like a pro😍🤩.</p>
        </div>
      </a>
    </div>
  </div>
</section>
  </div>
 <?php include 'ads.php'; ?> 
  <footer>
    <p>&copy; 2025 TOOLOI. All rights reserved.</p>
  </footer>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    function addPerson() {
      const container = document.getElementById("peopleContainer");
      const id = Date.now();
      const block = document.createElement("div");
      block.className = "person-block";
      block.innerHTML = `
        <input type="text" placeholder="Name" id="name-${id}">
        <input type="date" id="dob-${id}">
        <input type="time" id="tob-${id}">
        <button onclick="this.parentElement.remove()">Remove</button>
      `;
      container.appendChild(block);
    }

    function calculateAge(name, dobStr, tobStr) {
      if (!dobStr) return `${name}: Please enter a valid date`;

      const dob = new Date(`${dobStr}T${tobStr || "00:00"}`);
      const now = new Date();
      if (dob > now) return `${name}: Invalid DOB`;

      let years = now.getFullYear() - dob.getFullYear();
      let months = now.getMonth() - dob.getMonth();
      let days = now.getDate() - dob.getDate();
      let hours = now.getHours() - dob.getHours();
      let minutes = now.getMinutes() - dob.getMinutes();
      let seconds = now.getSeconds() - dob.getSeconds();

      if (seconds < 0) { seconds += 60; minutes--; }
      if (minutes < 0) { minutes += 60; hours--; }
      if (hours < 0) { hours += 24; days--; }
      if (days < 0) {
        months--;
        const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
        days += prevMonth.getDate();
      }
      if (months < 0) { months += 12; years--; }

      return `${name}: ${years}y, ${months}m, ${days}d, ${hours}h, ${minutes}min, ${seconds}s`;
    }

    function calculateAll() {
      const people = document.querySelectorAll(".person-block");
      const resultArea = document.getElementById("resultArea");
      resultArea.innerHTML = "";

      people.forEach(block => {
        const name = block.querySelector("input[type=text]").value || "Unnamed";
        const dob = block.querySelector("input[type=date]").value;
        const tob = block.querySelector("input[type=time]").value;
        const age = calculateAge(name, dob, tob);
        const p = document.createElement("p");
        p.textContent = age;
        resultArea.appendChild(p);
      });
    }

    function downloadCertificates() {
      const people = document.querySelectorAll(".person-block");
      let content = "";

      people.forEach(block => {
        const name = block.querySelector("input[type=text]").value || "Unnamed";
        const dob = block.querySelector("input[type=date]").value;
        const tob = block.querySelector("input[type=time]").value;
        content += calculateAge(name, dob, tob) + "\n";
      });

      const blob = new Blob([content], { type: "text/plain" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "age_certificates.txt";
      link.click();
    }

    function shareAges() {
      const people = document.querySelectorAll(".person-block");
      let content = "";

      people.forEach(block => {
        const name = block.querySelector("input[type=text]").value || "Unnamed";
        const dob = block.querySelector("input[type=date]").value;
        const tob = block.querySelector("input[type=time]").value;
        content += calculateAge(name, dob, tob) + "\n";
      });

      if (navigator.share) {
        navigator.share({
          title: "Age Summary",
          text: content,
        }).catch(console.error);
      } else {
        alert("Sharing not supported on this device.");
      }
    }

    function exportToExcel() {
      const people = document.querySelectorAll(".person-block");
      const data = [["Name", "DOB", "TOB", "Age"]];

      people.forEach(block => {
        const name = block.querySelector("input[type=text]").value || "Unnamed";
        const dob = block.querySelector("input[type=date]").value;
        const tob = block.querySelector("input[type=time]").value;
        data.push([name, dob, tob, calculateAge(name, dob, tob).replace(`${name}: `, "")]);
      });

      const worksheet = XLSX.utils.aoa_to_sheet(data);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Ages");

      XLSX.writeFile(workbook, "age_data.xlsx");
    }

    async function downloadPDF() {
      const people = document.querySelectorAll(".person-block");
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();

      let y = 10;
      people.forEach((block, i) => {
        const name = block.querySelector("input[type=text]").value || "Unnamed";
        const dob = block.querySelector("input[type=date]").value;
        const tob = block.querySelector("input[type=time]").value;
        const age = calculateAge(name, dob, tob);
        doc.text(`${i + 1}. ${age}`, 10, y);
        y += 10;
      });

      doc.save("age_certificates.pdf");
    }

    // Initialize
    window.onload = addPerson;
  </script>

</body>
</html>