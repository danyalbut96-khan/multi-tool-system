<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Meme Generator - TOOLOI</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Segoe+UI&display=swap" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      padding: 20px;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    .menu-btn {
      position: fixed;
      top: 10px;
      left: 10px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 8px 12px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 0.9em;
    }

    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    main {
      max-width: 600px;
      margin: auto;
      padding: 70px 20px 20px;
      text-align: center;
    }

    .meme-container {
      margin-top: 20px;
      position: relative;
      display: inline-block;
    }

    canvas, video, img {
      max-width: 100%;
      border: 1px solid #ccc;
      cursor: pointer;
      border-radius: 8px;
    }

    input, select, button {
      margin-top: 10px;
      width: 100%;
      padding: 10px;
      font-size: 1em;
    }

    button {
      background: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    button:hover {
      background: #0056b3;
    }

    .range-label {
      margin-top: 10px;
      text-align: left;
      font-weight: bold;
    }

    .color-picker {
      width: 50px;
      height: 30px;
      margin-top: 10px;
    }

    .ad-slot {
      margin: 40px 0;
      background: #eaeaea;
      padding: 30px;
      text-align: center;
      border: 2px dashed #ccc;
      color: #666;
      font-style: italic;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }

    .video-container {
      margin-top: 20px;
      position: relative;
      display: inline-block;
      width: 100%;
      text-align: center;
    }

    .preview-container {
      position: relative;
      margin-top: 20px;
      max-width: 100%;
      display: block;
      text-align: center;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰</button>

  <nav class="sidebar" id="sidebar">
    <h2>TOOLOI</h2>
    <a href="index.html">Home</a>
    <a href="about.html">About</a>
  </nav>

  <header>
    <h1>Meme Generator</h1>
    <p>Create your own memes with emojis, color & more</p>
  </header>

  <main>
    <input type="file" id="fileUpload" accept="image/*,video/*" />
    <input type="text" id="topText" placeholder="Top text (you can add emojis)" />
    <input type="text" id="bottomText" placeholder="Bottom text (you can add emojis)" />

    <label class="range-label">Top Text Size</label>
    <input type="range" id="topSize" min="10" max="100" value="40" />
    <input type="color" id="topColor" class="color-picker" value="#ffffff" />

    <label class="range-label">Bottom Text Size</label>
    <input type="range" id="bottomSize" min="10" max="100" value="40" />
    <input type="color" id="bottomColor" class="color-picker" value="#ffffff" />

    <button onclick="drawMeme()">Generate Meme</button>
    <button onclick="saveAsPDF()">Save as PDF</button>

    <div class="preview-container">
      <canvas id="memeCanvas" width="500" height="500" style="display:none;"></canvas>
      <div id="preview" style="display:none;">
        <img id="imagePreview" />
        <video id="videoPreview" controls></video>
      </div>
    </div>

    <a id="downloadLink" style="display: none;" download="meme.png">Download Meme</a>

    <div class="ad-slot">Ad Slot - Your Ad Here</div>
  </main>

  <footer>
    &copy; 2025 TOOLOI. All rights reserved.
  </footer>

  <script>
    // Toggle sidebar functionality
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    const canvas = document.getElementById('memeCanvas');
    const ctx = canvas.getContext('2d');
    let img = new Image();
    let videoElement = document.getElementById('videoPreview');
    let previewContainer = document.getElementById('preview');
    let topTextPos = { x: 250, y: 50 };
    let bottomTextPos = { x: 250, y: 450 };
    let dragging = null;

    document.getElementById('fileUpload').addEventListener('change', e => {
      const file = e.target.files[0];
      const reader = new FileReader();

      if (file) {
        if (file.type.startsWith('image/')) {
          reader.onload = function(event) {
            img.onload = drawMeme;
            img.src = event.target.result;
            videoElement.style.display = 'none';
            document.getElementById('imagePreview').src = event.target.result;
            previewContainer.style.display = 'block';
            document.getElementById('imagePreview').style.display = 'block';
          };
        } else if (file.type.startsWith('video/')) {
          const videoURL = URL.createObjectURL(file);
          videoElement.src = videoURL;
          videoElement.style.display = 'block';
          document.getElementById('imagePreview').style.display = 'none';
          previewContainer.style.display = 'block';
        }
        reader.readAsDataURL(file);
      }
    });

    ['topText', 'bottomText', 'topSize', 'bottomSize', 'topColor', 'bottomColor'].forEach(id => {
      document.getElementById(id).addEventListener('input', drawMeme);
    });

    function drawMeme() {
      const topText = document.getElementById('topText').value;
      const bottomText = document.getElementById('bottomText').value;
      const topSize = parseInt(document.getElementById('topSize').value);
      const bottomSize = parseInt(document.getElementById('bottomSize').value);
      const topColor = document.getElementById('topColor').value;
      const bottomColor = document.getElementById('bottomColor').value;

      if (img.src) {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);
      }

      ctx.textAlign = "center";
      ctx.lineWidth = 4;
      ctx.strokeStyle = 'black';

      ctx.font = `${topSize}px Impact`;
      ctx.fillStyle = topColor;
      ctx.strokeText(topText, topTextPos.x, topTextPos.y);
      ctx.fillText(topText, topTextPos.x, topTextPos.y);

      ctx.font = `${bottomSize}px Impact`;
      ctx.fillStyle = bottomColor;
      ctx.strokeText(bottomText, bottomTextPos.x, bottomTextPos.y);
      ctx.fillText(bottomText, bottomTextPos.x, bottomTextPos.y);

      const link = document.getElementById('downloadLink');
      link.href = canvas.toDataURL();
      link.style.display = 'inline-block';
    }

    // Dragging functionality for top/bottom text
    canvas.addEventListener('mousedown', e => {
      const { offsetX, offsetY } = e;
      if (isInText(offsetX, offsetY, topTextPos)) dragging = 'top';
      else if (isInText(offsetX, offsetY, bottomTextPos)) dragging = 'bottom';
    });

    canvas.addEventListener('mousemove', e => {
      if (!dragging) return;
      const { offsetX, offsetY } = e;
      if (dragging === 'top') topTextPos = { x: offsetX, y: offsetY };
      else bottomTextPos = { x: offsetX, y: offsetY };
      drawMeme();
    });

    canvas.addEventListener('mouseup', () => dragging = null);
    canvas.addEventListener('mouseleave', () => dragging = null);

    function isInText(x, y, textPos) {
      return Math.abs(x - textPos.x) < 150 && Math.abs(y - textPos.y) < 50;
    }

    async function saveAsPDF() {
      const { jsPDF } = window.jspdf;
      const pdf = new jsPDF();
      pdf.addImage(canvas.toDataURL(), 'PNG', 10, 10, 180, 160);
      pdf.save("meme.pdf");
    }
  </script>
</body>
</html>