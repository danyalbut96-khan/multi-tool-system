<?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Code Minifier - TOOLOI</title>
  <link rel="stylesheet" href="https://tooloi.earningera.com/style.css" />
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      color: #222;
    }
    .menu-btn {
      position: fixed;
      top: 15px;
      left: 15px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 40px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }
    header h1 { font-size: 2.2em; }

    .tool-card {
      max-width: 800px;
      margin: 30px auto;
      background: white;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    .tool-card textarea {
      width: 100%;
      height: 200px;
      padding: 10px;
      font-size: 1rem;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-bottom: 15px;
      resize: vertical;
    }

    .options {
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      margin-bottom: 15px;
    }

    .options label {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 0.95rem;
    }

    .tool-card select,
    .tool-card button {
      padding: 10px 15px;
      font-size: 1rem;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    .tool-card button {
      background: #007bff;
      color: white;
      border: none;
      cursor: pointer;
    }

    .tool-card button:hover {
      background: #0056b3;
    }

    .output {
      margin-top: 20px;
    }

    .ad-slot {
      margin: 40px auto;
      max-width: 800px;
      background: #eaeaea;
      padding: 30px;
      text-align: center;
      border: 2px dashed #ccc;
      color: #666;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <div class="sidebar" id="sidebar">
         <h2></h2>
    <a href="https://tooloi.earningera.com/index.php">Home</a>
    <a href="https://tooloi.earningera.com/about.php">About</a>
    <a href="https://tooloi.earningera.com/developer-tools.php">Developer Tools</a>
  </div>

  <header>
    <h1>Code Minifier</h1>
    <p>Minify or beautify HTML, CSS, and JavaScript easily</p>
  </header>
 <div class="ad-slot"> <?php include 'ads.php'; ?> </div>
  <div class="main">
    <div class="tool-card">
      <textarea id="inputCode" placeholder="Paste your HTML, CSS, or JS code here..."></textarea>

      <div class="options">
        <label>
          Language:
          <select id="codeType">
            <option value="html">HTML</option>
            <option value="css">CSS</option>
            <option value="js">JavaScript</option>
          </select>
        </label>
        <label><input type="checkbox" id="removeComments" checked> Remove Comments</label>
        <label><input type="checkbox" id="collapseWhitespace" checked> Collapse Whitespace</label>
        <label><input type="checkbox" id="beautify"> Beautify Output</label>
      </div>

      <button onclick="processCode()">Process Code</button>

      <div class="output">
        <textarea id="outputCode" readonly placeholder="Minified or formatted code will appear here..."></textarea>
      </div>
    </div>

    <div class="ad-slot">
       <?php include 'ads.php'; ?> 
    </div>
  
<section class="tool-details">
  <div style="margin-top: 40px;">
    <h2 style="font-size:1.8em; margin-bottom: 15px;">☆● Developer Tools – Enhance Your Coding Workflow ●☆</h2> <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Need powerful tools to streamline your web development process? TOOLOI’s <a href="developer-tools.php"><strong>Developer Tools</strong></a> provide you with the best solutions for efficient code editing and optimization. Whether you're a beginner or an experienced developer, our tools simplify your coding tasks with precision and speed.
    </p>

    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ HTML Code Runner:</strong> Write, test, and execute HTML code instantly with the <strong>HTML Code Runner</strong>. This tool allows you to quickly preview your HTML projects without leaving your browser, helping you work faster and more efficiently.
    </p>
 <?php include 'ads.php'; ?> 
    <p style="margin-bottom: 25px; line-height: 1.7;">
      <strong>☆ Code Minifier (HTML, CSS, JS):</strong> Need to reduce your code size for better performance? Our <strong>Code Minifier</strong> helps you compress HTML, CSS, and JavaScript files by removing unnecessary spaces, comments, and characters. It makes your code more efficient and improves page loading speeds, perfect for optimizing your websites and apps.
    </p>

    <p style="margin-bottom: 45px; line-height: 1.7;">
      ---> Whether you're running HTML code live or minifying your files for faster loading, TOOLOI's <strong>Developer Tools</strong> make web development tasks quicker, easier, and more optimized. Enhance your coding experience with our free online tools!
    </p>
  </div>
</section> <?php include 'ads.php'; ?> 
<section class="tool-details" style="padding: 60px 0; background-color: #f9f9f9; border-top: 2px solid #eaeaea; animation: fadeIn 1.2s;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    <h2 style="font-size: 2.2em; font-weight: bold; color: #333; margin-bottom: 30px; text-align: center;">
     ☆● Explore Our Powerful Free Online Tools ●☆ (seriously, They're Awesome)
    </h2>
    <p style="font-size: 1.1em; color: #666; line-height: 1.7; text-align: center; margin-bottom: 40px;">
      ---> Don’t take our word for it—dive into TOOLOI and see for yourself! Our tools are designed to boost your productivity, creativity, and workflow, whether you're working with images, PDFs, text, or developing a new website. Whatever you need, we’ve got you covered.
    </p>

    <!-- Image Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="image-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-image" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Image Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Edit, resize, and create stunning visuals in a flash😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- PDF Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="pdf-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-file-pdf" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°PDF Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Convert, compress, and split your PDFs with ease😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Unit & Conversion Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="unit-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-ruler-combined" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Unit & Conversion Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Converting units and currencies has never been this easy😍🤩.</p>
        </div>
      </a>
    </div>

    <!-- Developer Tools Section -->
    <div class="tool-category" style="margin-bottom: 40px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
      <a href="developer-tools.php" style="text-decoration: none; color: inherit; display: block;">
        <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px; text-align: center;">
          <i class="fas fa-code" style="font-size: 3em; color: #1a73e8;"></i>
          <h3 style="font-size: 1.8em; color: #1a73e8; font-weight: bold; margin: 15px 0;">°Developer Tools°</h3>
          <p style="font-size: 1.2em; color: #555; line-height: 1.6;">🤩😍Format, minify, and test your code like a pro😍🤩.</p>
        </div>
      </a>
    </div>
  </div>
</section> <?php include 'ads.php'; ?> 
</div>
</div>
  <footer>
    <p>&copy; 2025 TOOLOI. All rights reserved.</p>
  </footer>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    function processCode() {
      const input = document.getElementById("inputCode").value;
      const type = document.getElementById("codeType").value;
      const removeComments = document.getElementById("removeComments").checked;
      const collapseWhitespace = document.getElementById("collapseWhitespace").checked;
      const beautify = document.getElementById("beautify").checked;
      let output = input;

      if (!beautify) {
        if (removeComments) {
          if (type === "html") output = output.replace(/<!--[\s\S]*?-->/g, '');
          if (type === "js") output = output.replace(/\/\/.*|\/\*[\s\S]*?\*\//g, '');
          if (type === "css") output = output.replace(/\/\*[\s\S]*?\*\//g, '');
        }

        if (collapseWhitespace) {
          output = output.replace(/\s+/g, ' ').replace(/>\s+</g, '><');
        }
      } else {
        if (type === "html") output = beautifyHTML(output);
        if (type === "css") output = beautifyCSS(output);
        if (type === "js") output = beautifyJS(output);
      }

      document.getElementById("outputCode").value = output;
    }

    function beautifyHTML(code) {
      return code.replace(/></g, '>\n<').replace(/^\s+|\s+$/g, '');
    }

    function beautifyCSS(code) {
      return code.replace(/}/g, '}\n').replace(/{/g, ' {\n  ').replace(/;/g, ';\n  ').trim();
    }

    function beautifyJS(code) {
      return code.replace(/;/g, ';\n').replace(/{/g, ' {\n').replace(/}/g, '\n}').trim();
    }
  </script>

</body>
</html>