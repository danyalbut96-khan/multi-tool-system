<?php include 'visitor_tracker.php'; ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Word to PDF Converter - TOOLOI</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Segoe+UI&display=swap" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://unpkg.com/mammoth/mammoth.browser.min.js"></script>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
      padding: 20px;
    }

    header {
      background: linear-gradient(135deg, #007bff, #00d4ff);
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    .menu-btn {
      position: fixed;
      top: 10px;
      left: 10px;
      z-index: 1001;
      background: #007bff;
      color: white;
      padding: 6px 10px;
      font-size: 0.9em;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px;
      height: 100%;
      background: #007bff;
      color: white;
      padding: 20px;
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      transform: translateX(0);
    }

    .sidebar h2 {
      font-size: 1.5em;
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      margin: 15px 0;
      font-size: 1.1em;
    }

    .sidebar a:hover {
      text-decoration: underline;
    }

    main {
      max-width: 700px;
      margin: auto;
      padding: 70px 20px 20px;
    }

    input[type="file"], button {
      margin-top: 15px;
      width: 100%;
      padding: 12px;
      font-size: 1em;
      border-radius: 5px;
      border: none;
    }

    button {
      background: #007bff;
      color: white;
      cursor: pointer;
    }

    button:hover {
      background: #0056b3;
    }

    #preview {
      margin-top: 20px;
      background: white;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      min-height: 200px;
      overflow: auto;
    }

    .ad-slot {
      margin: 40px 0;
      background: #eaeaea;
      padding: 30px;
      text-align: center;
      border: 2px dashed #ccc;
      color: #666;
      font-style: italic;
    }

    footer {
      text-align: center;
      padding: 30px 0;
      margin-top: 40px;
      background: #f0f0f0;
    }
  </style>
</head>
<body>

  <button class="menu-btn" onclick="toggleSidebar()">☰ Menu</button>

  <nav class="sidebar" id="sidebar">
    <h2>TOOLOI</h2>
    <a href="https://tooloi.earningera.com/index.html">Home</a>
    <a href="https://tooloi.earningera.com/about.html">About</a>
  </nav>

  <header>
    <h1>Word to PDF Converter</h1>
    <p>Upload a Word file or paste content to convert to PDF</p>
  </header>
   <div class="ad-slot">Ad Slot - Your Ad Here</div>

  <main>
    <input type="file" id="uploadDoc" accept=".doc,.docx" />
    <div id="preview" contenteditable="true">Preview content will appear here...</div>
    <button onclick="convertToPDF()">Convert to PDF</button>

    <div class="ad-slot">Ad Slot - Your Ad Here</div>
  </main>

  <footer>
    &copy; 2025 TOOLOI. All rights reserved.
  </footer>

  <script>
    function toggleSidebar() {
      document.getElementById("sidebar").classList.toggle("open");
    }

    document.getElementById("uploadDoc").addEventListener("change", function(event) {
      const reader = new FileReader();
      reader.onload = function(event) {
        const arrayBuffer = reader.result;
        mammoth.convertToHtml({ arrayBuffer: arrayBuffer })
          .then(result => {
            document.getElementById("preview").innerHTML = result.value;
          })
          .catch(err => {
            alert("Error reading document: " + err.message);
          });
      };
      reader.readAsArrayBuffer(event.target.files[0]);
    });

    async function convertToPDF() {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      const text = document.getElementById("preview").innerText.trim();

      if (!text) {
        alert("No content to convert.");
        return;
      }

      const lines = doc.splitTextToSize(text, 180);
      doc.text(lines, 10, 20);
      doc.save("converted.pdf");
    }
  </script>

</body>
</html>