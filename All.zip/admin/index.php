<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome Admin</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }
        .welcome-box {
            text-align: center;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .welcome-box h2 {
            margin-bottom: 20px;
        }
        .welcome-box a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #0066ff;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        }
        .welcome-box a:hover {
            background-color: #0047b3;
        }
    </style>
</head>
<body>
    <div class="welcome-box">
        <h2>Welcome back</h2>
        <a href="https://tooloi.earningera.com/admin-login.php">Click Here</a>
    </div>
</body>
</html>